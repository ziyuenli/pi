import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readdirSync, readFileSync, renameSync, unlinkSync, writeSync } from "node:fs";
import { join } from "node:path";
import { isBase, type Op } from "@earendil-works/chord/delta";
import { MemoryStorage } from "./memory.ts";
import type { DocRef, Id, Seq, Storage, Write } from "./types.ts";

interface Record_ {
	seq: Seq;
	maxId: Id;
	writes: Write[];
}

/**
 * Files:
 *   main.jsonl                   conversations, entries, inputs, rewindable/session doc ops, and each
 *                                task's CREATE and TERMINAL records. History. Append-only, never rewritten.
 *   sticky-<conversation>.jsonl  sticky doc ops; rewritten from its last base by `truncate`
 *   task-<id>.jsonl              a live task's intermediate patches (running, checkpoints); unlinked on terminal
 *
 * A task costs main.jsonl its create and its terminal; everything in between lives in
 * a sidecar that disappears with the task. Replay: main, then only the sidecars of
 * tasks main says are still live. Records are `{seq, maxId, writes}`; `maxId` is the
 * committed-ID high-water after the batch, carried by every record of every file, so
 * IDs minted only in a retired sidecar are never reused. There is no compaction.
 */
export class JsonlStorage extends MemoryStorage implements Storage {
	private mainFd: number;
	private readonly sidecars = new Map<Id, number>(); // sticky docs, by conversation
	private readonly taskSidecars = new Map<Id, number>();
	private readonly dir: string;
	readonly fsync: boolean;

	private constructor(dir: string, fsync: boolean) {
		super();
		this.dir = dir;
		this.fsync = fsync;
		this.mainFd = openSync(join(dir, "main.jsonl"), "a");
	}

	static async open(dir: string, opts: { fsync?: boolean } = {}): Promise<JsonlStorage> {
		mkdirSync(dir, { recursive: true });
		const s = new JsonlStorage(dir, opts.fsync ?? true);
		await s.replay();
		return s;
	}

	private async replay() {
		let maxId = 0;
		const apply = async (file: string) => {
			if (!existsSync(file)) return;
			const text = readFileSync(file, "utf8");
			const end = text.lastIndexOf("\n");
			const body = end < 0 ? "" : text.slice(0, end); // bytes after the last newline are a torn write
			for (const line of body.split("\n")) {
				if (line === "") continue;
				const r = JSON.parse(line) as Record_;
				await super.commit(r.writes);
				maxId = Math.max(maxId, r.maxId);
			}
		};
		await apply(join(this.dir, "main.jsonl"));
		for (const f of readdirSync(this.dir)) if (f.startsWith("sticky-")) await apply(join(this.dir, f));
		// Task sidecars: replay only for tasks main says are live; a leftover for a terminal task is unlinked.
		for (const f of readdirSync(this.dir)) {
			if (!f.startsWith("task-")) continue;
			const id = Number(f.slice(5, -6));
			const t = await super.task(id);
			if (t !== undefined && t.status !== "terminal") await apply(join(this.dir, f));
			else unlinkSync(join(this.dir, f));
		}
		this.setNextId(maxId + 1);
		await this.pruneTerminal();
	}

	override async commit(writes: Write[]): Promise<Seq> {
		const seq = await super.commit(writes);
		const maxId = this.currentMaxId();
		const main: Write[] = [];
		const sticky = new Map<Id, Write[]>();
		const tasks = new Map<Id, Write[]>();
		const retired: Id[] = [];
		for (const w of writes) {
			if (w.type === "doc" && w.ref.doc === "sticky") {
				(sticky.get(w.ref.conversationId) ?? sticky.set(w.ref.conversationId, []).get(w.ref.conversationId)!).push(w);
			} else if (w.type === "task.patch" && w.patch.status !== "terminal") {
				(tasks.get(w.patch.id) ?? tasks.set(w.patch.id, []).get(w.patch.id)!).push(w);
			} else {
				main.push(w);
				if (w.type === "task.patch" && w.patch.status === "terminal") retired.push(w.patch.id);
			}
		}
		// Sidecars first, main last: main's record is what proves a terminal and carries the high-water.
		for (const [id, ws] of tasks) this.append(this.taskSidecar(id), { seq, maxId, writes: ws });
		for (const [c, ws] of sticky) this.append(this.sidecar(c), { seq, maxId, writes: ws });
		if (main.length) this.append(this.mainFd, { seq, maxId, writes: main });
		for (const id of retired) this.retireTaskSidecar(id);
		return seq;
	}

	override async truncate(ref: DocRef): Promise<void> {
		await super.truncate(ref);
		if (ref.doc !== "sticky") return;
		// Rewrite the sidecar to its last base and everything after.
		const file = join(this.dir, `sticky-${ref.conversationId}.jsonl`);
		if (!existsSync(file)) return;
		const lines = readFileSync(file, "utf8").split("\n").filter(Boolean);
		let lastBase = 0;
		for (let i = 0; i < lines.length; i++) {
			const r = JSON.parse(lines[i]!) as Record_;
			if (r.writes.some((w) => w.type === "doc" && isBase(w.ops))) lastBase = i;
		}
		const kept = lines.slice(lastBase).join("\n") + "\n";
		const tmp = `${file}.tmp`;
		const fd = openSync(tmp, "w");
		writeSync(fd, kept);
		if (this.fsync) fsyncSync(fd);
		closeSync(fd);
		const old = this.sidecars.get(ref.conversationId);
		if (old !== undefined) closeSync(old);
		renameSync(tmp, file);
		this.sidecars.set(ref.conversationId, openSync(file, "a"));
	}

	private fdsClosed = false;
	override async close() {
		if (this.fdsClosed) return;
		this.fdsClosed = true;
		await super.close();
		closeSync(this.mainFd);
		for (const fd of this.sidecars.values()) closeSync(fd);
		for (const fd of this.taskSidecars.values()) closeSync(fd);
	}

	private taskSidecar(id: Id): number {
		let fd = this.taskSidecars.get(id);
		if (fd === undefined) {
			fd = openSync(join(this.dir, `task-${id}.jsonl`), "a");
			this.taskSidecars.set(id, fd);
		}
		return fd;
	}
	private retireTaskSidecar(id: Id) {
		const fd = this.taskSidecars.get(id);
		if (fd !== undefined) closeSync(fd);
		this.taskSidecars.delete(id);
		try { unlinkSync(join(this.dir, `task-${id}.jsonl`)); } catch {}
	}

	private sidecar(conversationId: Id): number {
		let fd = this.sidecars.get(conversationId);
		if (fd === undefined) {
			fd = openSync(join(this.dir, `sticky-${conversationId}.jsonl`), "a");
			this.sidecars.set(conversationId, fd);
		}
		return fd;
	}

	private append(fd: number, record: Record_) {
		writeSync(fd, `${JSON.stringify(record)}\n`);
		if (this.fsync) fsyncSync(fd);
	}

	/** Bytes on disk, for the benchmark. */
	sizes(): Record<string, number> {
		const out: Record<string, number> = {};
		for (const f of readdirSync(this.dir)) out[f] = readFileSync(join(this.dir, f)).length;
		return out;
	}
}

export type { Op };
