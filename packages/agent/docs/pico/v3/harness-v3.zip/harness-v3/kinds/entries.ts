import type { AssistantMessage, ToolResultMessage, UserMessage } from "@earendil-works/pi-ai";
import { defineEntry, type Entry, type Id, type SystemMessage, type ToolControl } from "../types.ts";

export type UserEntry = Entry & { kind: "pi.user"; model: [UserMessage]; data?: { continuation: true; from: Id } };
export type AssistantEntry = Entry & { kind: "pi.assistant"; model: [AssistantMessage]; data: { attempt: number } };
export type ToolResultEntry = Entry & { kind: "pi.tool_result"; model: [ToolResultMessage]; data: { details?: unknown; diagnostics?: unknown; control?: ToolControl; truncated?: { bytes: number; lines: number } } };
export type SystemEntry = Entry & { kind: "pi.system"; model: [SystemMessage]; data: { baseline: boolean } };
export type NoticeEntry = Entry & { kind: "pi.notice"; model: [UserMessage] };
export type UsageEntry = Entry & { kind: "pi.usage"; data: { attempt: number; usage?: AssistantMessage["usage"]; error: string } };
export type SummaryEntry = Entry & { kind: "pi.summary"; model: [UserMessage]; data: { through: Id }; head: Id };
export type HandoffEntry = Entry & { kind: "pi.handoff"; model: [UserMessage]; head: Id };
export type ResetEntry = Entry & { kind: "pi.reset"; head: Id };

export const entries = {
	user: defineEntry<UserEntry>("pi.user"),
	assistant: defineEntry<AssistantEntry>("pi.assistant"),
	toolResult: defineEntry<ToolResultEntry>("pi.tool_result"),
	system: defineEntry<SystemEntry>("pi.system"),
	notice: defineEntry<NoticeEntry>("pi.notice"),
	usage: defineEntry<UsageEntry>("pi.usage"),
	summary: defineEntry<SummaryEntry>("pi.summary"),
	handoff: defineEntry<HandoffEntry>("pi.handoff"),
	reset: defineEntry<ResetEntry>("pi.reset"),
} as const;
