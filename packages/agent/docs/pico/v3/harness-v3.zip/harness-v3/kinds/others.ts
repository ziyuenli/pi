import type { Context } from "@earendil-works/chord";
import type { AssistantMessage, ToolCall, ToolResultMessage } from "@earendil-works/pi-ai";
import { estimateContextTokens } from "@earendil-works/pi-ai/utils/estimate";
import { effectiveTools } from "../system.ts";
import type { Closure, Completion, Entry, HookInfo, Id, Kind, ModelRef, ProcessSpec, RequestMessage, RetryPolicy, Runtime, Step, SystemMessage, Task, TaskRef, ThinkingLevel, ToolApi, ToolControl, ToolSlot } from "../types.ts";
import { defineTask } from "../types.ts";
import { retryDecision } from "./generation.ts";
import type { ToolTaskResult } from "./tool.ts";

const estimate = (messages: RequestMessage[]) => estimateContextTokens(messages.filter((m): m is Exclude<RequestMessage, SystemMessage> => m.role !== "system")).tokens;

// ===========================================================================
// pi.post_tools — no checkpoint: `initial` is the whole thing.
// ===========================================================================

export interface PostToolsInput {
	inputs: Id[];
	assistant: Id;
	tools: Id[];
}
export interface PostToolsResult {
	successor?: Id;
	ended?: "terminate" | "handoff";
}
export interface PostToolsHooks {
	/** After every tool of the assistant message is terminal, before the continuation. Observer. */
	afterTools(assistant: Id, results: Id[], info: HookInfo, ctx: Context): void | Promise<void>;
}
export const postToolsConfig = { sticky: { steeringMode: "one-at-a-time" as "all" | "one-at-a-time", followUpMode: "one-at-a-time" as "all" | "one-at-a-time" } } as const;

export const postTools: Kind<PostToolsInput, never, PostToolsResult, never, null, PostToolsHooks, typeof postToolsConfig> = {
	name: "pi.post_tools",
	core: true,
	turn: true,
	config: postToolsConfig,
	phases: {},

	async initial(task, rt, ctx) {
		// Snapshot of terminal tool tasks in call order. Terminal records never change.
		const rows = await rt.commit(async (tx) => {
			const assistant = await tx.entry(task.input.assistant);
			const calls = ((assistant?.model?.[0] as AssistantMessage | undefined)?.content ?? []).filter((c): c is ToolCall => c.type === "toolCall");
			return Promise.all(task.input.tools.map(async (id, i) => {
				const t = (await tx.task(id))!;
				const call = calls[i]!;
				if (t.outcome?.status === "completed") { const r = t.outcome.result as ToolTaskResult; return { call, entry: r.entry as Id | undefined, control: r.control, missing: undefined as "orphaned" | "aborted" | undefined }; }
				if (t.outcome?.status === "aborted") { const a = t.outcome.result as { entry?: Id }; return { call, entry: a.entry, control: undefined, missing: a.entry === undefined ? ("aborted" as const) : undefined }; }
				return { call, entry: undefined, control: undefined, missing: "orphaned" as const };
			}));
		}, ctx);
		const results = rows.map((r) => r.entry).filter((e): e is Id => e !== undefined);
		await rt.hooks.each(ctx, (h) => h.afterTools?.(task.input.assistant, results, { taskId: task.id, conversationId: task.conversationId }, ctx));

		return {
			done: async (tx, current) => {
				const c = current.conversationId;
				const state = tx.rewindable(c);
				// Fold control in call order. addTools additive; handoff wins over terminate; last handoff wins.
				const addTools = [...state.selectedTools];
				let terminate = false;
				let handoff: string | undefined;
				for (const r of rows) {
					for (const n of r.control?.addTools ?? []) if (!addTools.includes(n)) addTools.push(n);
					if (r.control?.terminate) terminate = true;
					if (r.control?.handoff !== undefined) handoff = r.control.handoff;
				}
				if (addTools.length !== state.selectedTools.length) state.selectedTools = addTools;
				for (const r of rows) {
					if (r.missing === undefined) continue;
					tx.appendEntry(c, { kind: "pi.tool_result", model: [{ role: "toolResult", toolCallId: r.call.id, toolName: r.call.name, content: [{ type: "text", text: `Tool result unavailable: task ${r.missing}.` }], isError: true, timestamp: rt.now() } as ToolResultMessage], data: { diagnostics: [{ severity: "error", message: r.missing, code: r.missing }] } });
				}
				if (handoff !== undefined) tx.appendEntry(c, { kind: "pi.handoff", head: "self", model: [{ role: "user", content: handoff, timestamp: rt.now() }] });
				if (handoff !== undefined || terminate) {
					tx.sticky(c).turn = { tools: [] };
					await tx.resolveInputs(task.input.inputs, { status: "done", answer: task.input.assistant });
					const { triggers } = await tx.boundary(c, "final");
					const ended = handoff !== undefined ? "handoff" : "terminate";
					return { status: "completed", result: triggers.length ? { ended, successor: tx.createTask({ kind: "pi.generation", input: { inputs: triggers } }) } : { ended } };
				}
				const { triggers, terminated } = await tx.boundary(c, "postTools");
				if (terminated) {
					await tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "terminated" });
					return { status: "completed", result: triggers.length ? { successor: tx.createTask({ kind: "pi.generation", input: { inputs: triggers } }) } : {} };
				}
				return { status: "completed", result: { successor: tx.createTask({ kind: "pi.generation", input: { inputs: [...task.input.inputs, ...triggers] } }) } };
			},
		};
	},

	async abort(task) {
		return async (tx, current) => {
			tx.sticky(current.conversationId).turn = { tools: [] };
			await tx.resolveInputs(task.input.inputs, { status: "unanswered", reason: "aborted" });
			return null;
		};
	},
};

// ===========================================================================
// pi.collapse
// ===========================================================================

export interface CollapseInput {
	reason: "threshold" | "manual" | "overflow";
	through: Id;
	instructions?: string;
}
interface Base {
	expectedHead: Id | null;
	instructions?: string;
	model: ModelRef;
	thinkingLevel: ThinkingLevel;
	retry: RetryPolicy;
	attempt: number;
}
export type CollapseCheckpoint = ({ phase: "summarizing" } & Base) | ({ phase: "retrying"; untilMs: number; lastError: string } & Base) | ({ phase: "prepared"; summary: string } & Base);
export interface CollapseFailure {
	reason: "stale" | "declined" | "provider" | "retries_exhausted" | "no_model";
	detail: string;
}
export interface CollapseHooks {
	/** Before summarizing. First answer wins: decline, supply the summary, or adjust instructions. */
	beforeCollapse(reason: "threshold" | "manual" | "overflow", through: Id, entries: Entry[], info: HookInfo, ctx: Context): { decline: true } | { instructions?: string; summary?: string } | void | Promise<{ decline: true } | { instructions?: string; summary?: string } | void>;
}
export const collapseConfig = { rewindable: { threshold: 0 as number, keepRecent: 20_000 as number } } as const;

type C = Task<CollapseInput, CollapseCheckpoint>;
type CRt = Runtime<CollapseHooks>;
type CS = Step<CollapseCheckpoint, { summary: Id }, CollapseFailure>;
const cfail = (reason: CollapseFailure["reason"], detail: string): Completion<{ summary: Id }, CollapseFailure> => ({ status: "failed", failure: { reason, detail } });
const baseOf = (cp: CollapseCheckpoint): Base => { const { phase: _p, ...rest } = cp; const { untilMs: _u, lastError: _l, summary: _s, ...base } = rest as Base & { untilMs?: number; lastError?: string; summary?: string }; return base; };

export const collapse: Kind<CollapseInput, CollapseCheckpoint, { summary: Id }, CollapseFailure, null, CollapseHooks, typeof collapseConfig> = {
	name: "pi.collapse",
	core: true,
	config: collapseConfig,

	// Snapshot, hook off the line, then one transition that re-checks the head atomically
	// with the checkpoint — and either summarizes, finalizes a hook-supplied summary, or stales.
	async initial(task, rt, ctx) {
		const state = await rt.rewindable(task.conversationId, ctx);
		if (state.model === undefined) return { done: () => cfail("no_model", "no model configured") };
		const sticky = await rt.sticky(task.conversationId, ctx);
		const head = await rt.newestEntry(task.conversationId, { withHead: true }, ctx);
		const { entries } = await rt.context(task.conversationId, task.input.through, ctx);
		let decision: { decline: true } | { instructions?: string; summary?: string } = {};
		await rt.hooks.each(ctx, (h) => h.beforeCollapse?.(task.input.reason, task.input.through, entries, { taskId: task.id, conversationId: task.conversationId }, ctx), (v) => { decision = v; return true; });
		if ("decline" in decision) return { done: () => cfail("declined", "declined by beforeCollapse") };
		const d: { instructions?: string; summary?: string } = decision;
		const base: Base = { expectedHead: head?.id ?? null, ...(d.instructions ?? task.input.instructions ? { instructions: d.instructions ?? task.input.instructions } : {}), model: state.model, thinkingLevel: state.thinkingLevel, retry: sticky.retry, attempt: 1 };
		// A hook-supplied summary skips the provider: transition to `prepared`, staling if the head moved.
		if (d.summary !== undefined) {
			const summary = d.summary;
			return { next: async (tx, current) => (await headMoved(tx, current.conversationId, base) ? cfail("stale", "head moved during beforeCollapse") : { phase: "prepared", summary, ...base }) };
		}
		// Otherwise `summarizing` is an in-flight checkpoint: written here, atomically with the head check, before the call.
		return summarizeNow(task, base, rt, ctx, "check head");
	},

	phases: {
		// Only after a crash: the call may have happened. Count it as a failed attempt.
		async summarizing(task, rt) {
			return afterFailure(baseOf(task.checkpoint), null, "interrupted", rt);
		},
		async retrying(task, rt, ctx) {
			await rt.sleep(task.checkpoint.untilMs, ctx);
			return summarizeNow(task, { ...baseOf(task.checkpoint), attempt: task.checkpoint.attempt + 1 }, rt, ctx);
		},
		// The candidate text is durable; only finalization remains.
		async prepared(task) {
			const { summary } = task.checkpoint;
			const base = baseOf(task.checkpoint);
			return {
				done: async (tx, current) => {
					const { head, entries } = await tx.context(current.conversationId);
					if ((head?.id ?? null) !== base.expectedHead) return cfail("stale", "head moved during collapse");
					const retained = entries.find((e) => e.id > task.input.through);
					const id = tx.appendEntry(current.conversationId, { kind: "pi.summary", data: { through: task.input.through }, model: [{ role: "user", content: summary, timestamp: Date.now() }], head: retained?.id ?? "self" });
					return { status: "completed", result: { summary: id } };
				},
			};
		},
	},

	async abort() {
		return async () => null;
	},
};

const headMoved = async (tx: Pick<import("../types.ts").Tx, "newestEntry">, c: Id, base: Base) => ((await tx.newestEntry(c, { withHead: true }))?.id ?? null) !== base.expectedHead;

/** Write `summarizing` (optionally re-checking the head in the same commit), then call the provider. */
async function summarizeNow(task: C, base: Base, rt: CRt, ctx: Context, check?: "check head"): Promise<CS> {
	const stale = await rt.commit(async (tx, current) => {
		if (check && (await headMoved(tx, current.conversationId, base))) return true;
		tx.checkpoint({ phase: "summarizing", ...base });
		return false;
	}, ctx);
	if (stale) return { done: () => cfail("stale", "head moved during beforeCollapse") };
	const model = rt.models.resolve(base.model);
	if (model === undefined) return { done: () => cfail("no_model", "model unavailable") };
	const { messages } = await rt.context(task.conversationId, task.input.through, ctx);
	const effective = effectiveTools(messages);
	const request: RequestMessage[] = [
		...messages,
		...(effective.length ? [{ role: "system", content: "", toolsRemoved: effective, timestamp: rt.now() } as SystemMessage] : []),
		{ role: "user", content: `${base.instructions ?? "Summarize the conversation so far for continuation."}\n\nRespond with the summary only.`, timestamp: rt.now() },
	];
	let message: AssistantMessage | undefined;
	try {
		for await (const e of rt.models.stream(model, { messages: request, thinkingLevel: base.thinkingLevel }, ctx)) {
			if (e.type === "done") { message = e.message; break; }
			if (e.type === "error") { message = e.error; break; }
		}
	} catch (error) {
		if (ctx.abortSignal?.aborted) throw error;
		return afterFailure(base, null, String(error), rt);
	}
	if (message === undefined) return afterFailure(base, null, "no message", rt);
	if (message.content.some((c) => c.type === "toolCall")) return afterFailure(base, { ...message, stopReason: "error" }, "summarizer returned tool calls", rt);
	if (message.stopReason === "error") return afterFailure(base, message, message.errorMessage ?? "provider error", rt);
	const summary = message.content.filter((c): c is { type: "text"; text: string } => c.type === "text").map((c) => c.text).join("");
	return { next: { phase: "prepared", summary, ...base } };
}

function afterFailure(base: Base, message: AssistantMessage | null, detail: string, rt: CRt): CS {
	const decision = retryDecision(base, message, rt.now());
	if (decision.kind === "fail") return { done: () => cfail(decision.reason, detail) };
	return { next: { phase: "retrying", ...base, untilMs: decision.untilMs, lastError: detail } };
}

/** pico §10.1 "choosing through": walk exchanges from newest, keep while retained ≤ keepRecent. */
export function chooseThrough(entries: Entry[], keepRecent: number): Id | undefined {
	const exchanges: { last: Id; tokens: number }[] = [];
	let open: { last: Id; tokens: number } | undefined;
	for (const e of entries) {
		const role = e.model?.[0]?.role;
		const tokens = estimate((e.model ?? []) as RequestMessage[]);
		if (role === "assistant") exchanges.push((open = { last: e.id, tokens }));
		else if (role === "toolResult" && open) { open.last = e.id; open.tokens += tokens; }
		else { open = undefined; exchanges.push({ last: e.id, tokens }); }
	}
	let retained = 0;
	let i = exchanges.length - 1;
	while (i >= 0 && retained + exchanges[i]!.tokens <= keepRecent) retained += exchanges[i--]!.tokens;
	if (i < 0) return undefined;
	if (i === exchanges.length - 1) return exchanges[i - 1]?.last;
	return exchanges[i]!.last;
}

// ===========================================================================
// pi.job — ordinary kind over an injected ProcessHost.
// ===========================================================================

export interface JobInput extends ProcessSpec {
	notify: boolean;
	rerun: boolean;
	every?: number;
	notBefore?: number;
}
export type JobCheckpoint = { phase: "waiting"; untilMs: number; occurrence: number } | { phase: "spawning"; key: string; occurrence: number } | { phase: "running"; key: string; occurrence: number };
export type JobOutput = { stdout?: string; stderr?: string; droppedStdout?: number; droppedStderr?: number; exitCode?: number; occurrence?: number };
export type JobResult = { exitCode: number; occurrences: number; stdout: string; stderr: string };
export type JobFailure = { reason: "spawn" | "interrupted"; detail: string };
type J = Task<JobInput, JobCheckpoint>;
type JS = Step<JobCheckpoint, JobResult, JobFailure>;
const jfail = (reason: "spawn" | "interrupted", detail: string): Completion<JobResult, JobFailure> => ({ status: "failed", failure: { reason, detail } });
const notice = (text: string, now: number) => ({ kind: "pi.notice", model: [{ role: "user" as const, content: text, timestamp: now }] });

export const job = defineTask<JobInput, JobCheckpoint, JobResult, JobFailure, { killed: boolean }>({
	name: "pi.job",
	phases: {
		async waiting(task, rt, ctx) {
			await rt.sleep(task.checkpoint.untilMs, ctx);
			return spawn(task, task.checkpoint.occurrence, rt, ctx);
		},
		// Only after a crash: ask the host what it knows.
		async spawning(task, rt, ctx) { return reconcile(task, task.checkpoint, rt, ctx); },
		async running(task, rt, ctx) { return reconcile(task, task.checkpoint, rt, ctx); },
	},
	async initial(task, rt, ctx) {
		if (rt.processHost === undefined) return { done: () => jfail("spawn", "no process host") };
		const now = rt.now();
		const untilMs = task.input.notBefore ?? now;
		if (untilMs > now) return { next: { phase: "waiting", untilMs, occurrence: 1 } };
		return spawn(task, 1, rt, ctx);
	},
	async abort(task, rt, ctx) {
		const cp = task.checkpoint;
		if (cp === undefined || cp.phase === "waiting" || rt.processHost === undefined) return async () => ({ killed: false });
		await rt.processHost.kill(cp.key, "SIGTERM", ctx);
		await rt.sleep(rt.now() + 5000, ctx);
		await rt.processHost.kill(cp.key, "SIGKILL", ctx);
		return async () => ({ killed: true });
	},
});

/** Write `spawning` (the in-flight checkpoint) before any OS effect, start, write `running`, poll. */
async function spawn(task: J, occurrence: number, rt: Runtime, ctx: Context): Promise<JS> {
	const key = `${task.id}:${occurrence}`;
	await rt.commit((tx) => tx.checkpoint({ phase: "spawning", key, occurrence }), ctx);
	try {
		await rt.processHost!.start(key, task.input, ctx);
	} catch (error) {
		if (ctx.abortSignal?.aborted) throw error;
		return { done: async (tx, current) => { if (task.input.notify) await tx.write(current.conversationId, notice(`job ${task.id} failed to start: ${String(error)}`, rt.now())); return jfail("spawn", String(error)); } };
	}
	await rt.commit((tx) => tx.checkpoint({ phase: "running", key, occurrence }), ctx);
	return poll(task, key, occurrence, rt, ctx);
}

async function reconcile(task: J, cp: Extract<JobCheckpoint, { phase: "spawning" | "running" }>, rt: Runtime, ctx: Context): Promise<JS> {
	if (rt.processHost === undefined) return { done: () => jfail("interrupted", "no process host after restart") };
	let status;
	try { status = await rt.processHost.status(cp.key, ctx); } catch (error) { return { done: () => jfail("interrupted", `host status failed: ${String(error)}`) }; }
	if (status.status === "unknown") {
		if (!task.input.rerun) return { done: () => jfail("interrupted", "process outcome unknown") };
		return spawn(task, cp.occurrence, rt, ctx); // same key; possible duplicate effect, as §3.2 allows
	}
	if (cp.phase === "spawning") await rt.commit((tx) => tx.checkpoint({ phase: "running", key: cp.key, occurrence: cp.occurrence }), ctx);
	return poll(task, cp.key, cp.occurrence, rt, ctx);
}

async function poll(task: J, key: string, occurrence: number, rt: Runtime, ctx: Context): Promise<JS> {
	for (let n = 0; ; n++) {
		let s;
		try { s = await rt.processHost!.status(key, ctx); } catch (error) { return { done: () => jfail("interrupted", `host status failed: ${String(error)}`) }; }
		if (s.status === "unknown") {
			if (!task.input.rerun) return { done: () => jfail("interrupted", "process outcome unknown") };
			return spawn(task, occurrence, rt, ctx);
		}
		const snap = s;
		await rt.commit((tx, current) => { const o = tx.slot<JobOutput>(current); o.stdout = snap.stdout; o.stderr = snap.stderr; o.droppedStdout = snap.droppedStdout; o.droppedStderr = snap.droppedStderr; if (snap.status === "exited") o.exitCode = snap.exitCode; }, ctx);
		if (snap.status === "exited") {
			const { exitCode, stdout, stderr } = snap;
			if (task.input.every === undefined) {
				return { done: async (tx, current) => { if (task.input.notify) await tx.write(current.conversationId, notice(`job ${task.id} exited with code ${exitCode}`, rt.now())); return { status: "completed", result: { exitCode, occurrences: occurrence, stdout, stderr } }; } };
			}
			const untilMs = rt.now() + task.input.every;
			return {
				next: async (tx, current) => {
					if (task.input.notify) await tx.write(current.conversationId, notice(`job ${task.id} occurrence ${occurrence} exited with code ${exitCode}`, rt.now()));
					const o = tx.slot<JobOutput>(current);
					o.stdout = ""; o.stderr = ""; o.droppedStdout = 0; o.droppedStderr = 0; delete o.exitCode; o.occurrence = occurrence + 1;
					return { phase: "waiting", untilMs, occurrence: occurrence + 1 };
				},
			};
		}
		await rt.sleep(rt.now() + Math.min(1000, 100 * 2 ** Math.min(n, 4)), ctx);
	}
}

// ===========================================================================
// pi.plugin — the one generic task. A registered handler runs under our control.
// ===========================================================================

export interface PluginInput {
	handler: string;
	input: unknown;
}
export const plugin = defineTask<PluginInput, { phase: "started" }, unknown, { reason: string; detail: string }, null>({
	name: "pi.plugin",
	phases: {
		// After a crash the handler simply runs again. Handlers that care use their own keys.
		async started(task, rt, ctx) { return run(task, rt, ctx); },
	},
	async initial(task, rt, ctx) {
		await rt.commit((tx) => tx.checkpoint({ phase: "started" }), ctx);
		return run(task, rt, ctx);
	},
	async abort() { return async () => null; },
});
async function run(task: Task<PluginInput, { phase: "started" }>, rt: Runtime, ctx: Context): Promise<Step<{ phase: "started" }, unknown, { reason: string; detail: string }>> {
	const handler = rt.plugins.get(task.input.handler);
	if (handler === undefined) return { done: () => ({ status: "failed", failure: { reason: "missing_handler", detail: task.input.handler } }) };
	try {
		const result = await handler(task.input.input, taskApi(task, rt), ctx);
		return { done: () => ({ status: "completed", result }) };
	} catch (error) {
		if (ctx.abortSignal?.aborted) throw error;
		return { done: () => ({ status: "failed", failure: { reason: "threw", detail: String(error) } }) };
	}
}

// ===========================================================================
// The narrow surface a tool or plugin handler gets.
// ===========================================================================

export function taskApi(task: Task, rt: Runtime): ToolApi {
	const isKind = (x: unknown): x is Kind => typeof x === "object" && x !== null && "name" in x && "initial" in x;
	return {
		taskId: task.id,
		conversationId: task.conversationId,
		stream: () => { throw new Error("stream is only available to tools"); },
		progress: (update, ctx) => rt.commit((tx, current) => update(tx.slot<ToolSlot>(current)), ctx),
		async conversation(spec, ctx) {
			// Inheritance resolves off the line (the as-of read is its own line operation), then one commit creates.
			const tip = spec.inherit ? await rt.newestEntry(task.conversationId, {}, ctx) : undefined;
			const inherited = tip ? await rt.rewindableAsOf(task.conversationId, tip.id, ctx) : undefined;
			const id = await rt.commit((tx, current) =>
				spec.inherit
					? tx.createConversation({ parent: { conversationId: current.conversationId, at: tip?.id ?? "start" }, rewindable: { ...inherited, ...spec.rewindable }, sticky: spec.sticky })
					: tx.createConversation({ rewindable: spec.rewindable, sticky: spec.sticky }),
			ctx);
			return {
				id,
				send: async (input, c) => {
					const inputId = await rt.commit((tx) => tx.send(id, input), c);
					return { id: inputId, wait: (cc) => rt.waitForInput(inputId, cc), result: (cc) => rt.commit((tx) => tx.input(inputId), cc) };
				},
				abort: (c) => rt.abortConversation(id, c),
			};
		},
		task: ((a: Kind | import("../types.ts").TaskSpec, b: unknown, c?: unknown, d?: Context): Promise<TaskRef> =>
			isKind(a)
				? rt.commit((tx) => tx.createTask(a, b as never, c as { background?: true; after?: Id[] }), d!)
				: rt.commit((tx) => ({ id: tx.createTask(a), kind: rt.kinds.get(a.kind)! }), b as Context)) as ToolApi["task"],
		getTask: async (ref, ctx) => (await rt.commit((tx) => tx.task(ref.id), ctx)) as never,
		waitForTask: (ref, ctx) => rt.waitForTask(ref.id, ctx) as never,
		slot: (ref, ctx) => rt.commit((tx, current) => tx.snapshot({ doc: "sticky", conversationId: current.conversationId }).tasks[typeof ref === "number" ? ref : ref.id] as never, ctx),
	};
}

export type { ToolControl };
