import type { Context } from "@earendil-works/chord";
import type { ToolCall, ToolResultMessage } from "@earendil-works/pi-ai";
import { Value } from "@sinclair/typebox/value";
import { Bounded } from "../bounded.ts";
import type { Closure, Completion, HookInfo, Id, Kind, Runtime, Step, Task, ToolControl, ToolDeclaration, ToolResult, ToolSlot } from "../types.ts";
import { taskApi } from "./others.ts";

export interface ToolInput {
	assistant: Id;
	call: ToolCall;
	offered: string[];
	index: number; // position of the call in the assistant message; also this tool's slot in sticky.turn.tools
}
export type ToolCheckpoint = { phase: "started"; replay: "safe" | "unsafe"; call: ToolCall };
export interface ToolTaskResult {
	entry: Id;
	control?: ToolControl;
}
/** Hook points this kind calls. Register with `h.hooks(kinds.tool, { … })`. */
export interface ToolHooks {
	/** Before invocation. Chain on `call`; `{ block }` stops it. A throw blocks. */
	beforeTool(call: ToolCall, info: HookInfo, ctx: Context): { call?: ToolCall; block?: string } | void | Promise<{ call?: ToolCall; block?: string } | void>;
	/** After the tool returns; may replace the result. Chain. */
	afterTool(call: ToolCall, result: ToolResult, info: HookInfo, ctx: Context): ToolResult | void | Promise<ToolResult | void>;
}

type T = Task<ToolInput, ToolCheckpoint>;
type Rt = Runtime<ToolHooks>;
type S = Step<ToolCheckpoint, ToolTaskResult, never>;
type Out = Closure<ToolTaskResult, never>;

const synthetic = (text: string, code: string): ToolResult => ({ content: [{ type: "text", text }], isError: true, diagnostics: [{ severity: "error", message: text, code }] });
function invalid(declaration: ToolDeclaration, call: ToolCall): string | undefined {
	const errors = [...Value.Errors(declaration.parameters, call.arguments)];
	return errors.length === 0 ? undefined : errors.map((e) => `${e.path || "/"}: ${e.message}`).join("; ");
}
const sameIdentity = (a: ToolCall, b: ToolCall) => a.id === b.id && a.name === b.name && a.namespace === b.namespace;

export const tool: Kind<ToolInput, ToolCheckpoint, ToolTaskResult, never, { entry: Id }, ToolHooks> = {
	name: "pi.tool",
	core: true,
	turn: true,

	// Offered-set check, lookup, validate, beforeTool, validate again; then write `started`
	// (the in-flight checkpoint) and invoke. A crash before `started` reruns all of this,
	// which is correct: nothing external has happened.
	async initial(task, rt, ctx) {
		const call = task.input.call;
		const info = { taskId: task.id, conversationId: task.conversationId };
		if (!task.input.offered.includes(call.name)) return { done: close(task, synthetic(`tool ${call.name} was not offered`, "not_offered"), undefined) };
		const declaration = rt.tools.get(call.name);
		if (declaration === undefined) return { done: close(task, synthetic(`tool ${call.name} is not registered`, "missing_tool"), undefined) };
		const bad = invalid(declaration, call);
		if (bad !== undefined) return { done: close(task, synthetic(`invalid arguments: ${bad}`, "invalid_arguments"), declaration) };
		const hooked = await beforeTool(rt, call, info, ctx);
		if ("block" in hooked) return { done: close(task, synthetic(`blocked: ${hooked.block}`, "blocked"), declaration) };
		if (!sameIdentity(call, hooked.call)) return { done: close(task, synthetic("blocked: call identity changed", "blocked"), declaration) };
		const badFinal = invalid(declaration, hooked.call);
		if (badFinal !== undefined) return { done: close(task, synthetic(`invalid arguments after hook: ${badFinal}`, "invalid_arguments"), declaration) };

		await rt.commit((tx) => tx.checkpoint({ phase: "started", replay: declaration.replay ?? "unsafe", call: hooked.call }), ctx); // before the effect
		return { done: await invoke(task, hooked.call, declaration, rt, ctx) };
	},

	phases: {
		// Only after a crash. The stored final call is the evidence; beforeTool never reruns.
		async started(task, rt, ctx) {
			const cp = task.checkpoint;
			const declaration = rt.tools.get(cp.call.name);
			if (declaration === undefined) return { done: close(task, synthetic(`tool ${cp.call.name} unavailable after restart`, "unavailable"), undefined) };
			if (cp.replay !== "safe" || (declaration.replay ?? "unsafe") !== "safe") return { done: close(task, synthetic(`tool ${cp.call.name} was interrupted`, "interrupted"), declaration) };
			if (invalid(declaration, cp.call) !== undefined) return { done: close(task, synthetic(`tool ${cp.call.name} was interrupted; arguments no longer validate`, "interrupted"), declaration) };
			return { done: await invoke(task, cp.call, declaration, rt, ctx) };
		},
	},

	async abort(task, rt, ctx) {
		for (const conversationId of task.owns) {
			const children = await rt.commit((tx) => tx.tasks({ conversationId, status: ["pending", "running"] }), ctx);
			for (const child of children) if (!child.background) await rt.abortTask(child.id, ctx);
		}
		return (tx, current) => {
			const call = task.checkpoint?.call ?? task.input.call;
			const entry = tx.appendEntry(current.conversationId, { kind: "pi.tool_result", model: [toMessage(call, synthetic("tool aborted", "aborted"), rt.now())], data: { diagnostics: [{ severity: "error", message: "aborted", code: "aborted" }] } });
			return { entry };
		};
	},
};

/** The one point where a throwing handler blocks rather than being skipped. */
async function beforeTool(rt: Rt, call: ToolCall, info: HookInfo, ctx: Context): Promise<{ call: ToolCall } | { block: string }> {
	let current = call;
	for (const h of rt.hooks.handlers()) {
		let v: { call?: ToolCall; block?: string } | void;
		try {
			v = await h.beforeTool?.(current, info, ctx);
		} catch (error) {
			if (ctx.abortSignal?.aborted) throw error;
			return { block: `hook threw: ${String(error)}` };
		}
		if (!v) continue;
		if (v.block !== undefined) return { block: v.block };
		if (v.call !== undefined) current = v.call;
	}
	return { call: current };
}

export const DEFAULT_BOUNDS = { maxBytes: 64 * 1024, maxLines: 200, retain: "head" as const };

async function invoke(task: T, call: ToolCall, declaration: ToolDeclaration, rt: Rt, ctx: Context): Promise<Out> {
	// The kernel owns the stream: one bounded buffer, one throttle, one flush path.
	const b = { ...DEFAULT_BOUNDS, ...declaration.output };
	const buffer = new Bounded(b.maxBytes, b.retain);
	let streamed = false;
	let lastFlush = 0;
	let flushing: Promise<void> = Promise.resolve();
	const flush = () => {
		lastFlush = rt.now();
		const text = buffer.text();
		flushing = flushing.then(() => rt.commit((tx) => { tx.toolSlot(task).output = text; }, ctx)).catch(() => {});
	};
	const api = {
		...taskApi(task, rt),
		progress: (update: (slot: ToolSlot) => void, c: Context) => rt.commit((tx) => update(tx.toolSlot(task)), c),
		stream(chunk: string | Uint8Array) {
			streamed = true;
			buffer.push(typeof chunk === "string" ? new TextEncoder().encode(chunk) : chunk);
			if (rt.now() - lastFlush >= 100) flush();
		},
	};
	let result: ToolResult;
	try {
		result = await declaration.execute(call.arguments, api, ctx);
	} catch (error) {
		if (ctx.abortSignal?.aborted) throw error;
		result = synthetic(`tool threw: ${String(error)}`, "threw");
	}
	if (streamed) {
		flush();
		await flushing;
		if (result.content === undefined) result = { ...result, content: [{ type: "text", text: buffer.text() }], ...(buffer.dropped ? { diagnostics: [...(result.diagnostics ?? []), { severity: "warn" as const, code: "truncated", message: `${buffer.dropped} bytes dropped (${b.retain} ${b.maxBytes} retained)` }] } : {}) };
	}
	let final = result;
	await rt.hooks.each(ctx, (h) => h.afterTool?.(call, final, { taskId: task.id, conversationId: task.conversationId }, ctx), (v) => { final = v; });
	return close(task, final, declaration, streamed ? { bytes: buffer.dropped, lines: 0 } : undefined);
}

/** Closure: bound the output, store the exact model message, rest as data. */
function close(task: T, raw: ToolResult, declaration: ToolDeclaration | undefined, streamTruncated?: { bytes: number; lines: number }): Out {
	return (tx, current) => {
		const bounded = streamTruncated ? { result: raw, truncated: streamTruncated.bytes ? streamTruncated : undefined } : bound({ ...raw, content: raw.content ?? [] }, declaration?.output);
		const { result, truncated } = bounded;
		const entry = tx.appendEntry(current.conversationId, {
			kind: "pi.tool_result",
			model: [toMessage(task.input.call, result, Date.now())],
			data: { ...(result.details === undefined ? {} : { details: result.details }), ...(result.diagnostics === undefined ? {} : { diagnostics: result.diagnostics }), ...(result.control === undefined ? {} : { control: result.control }), ...(truncated === undefined ? {} : { truncated }) },
		});
		const completion: Completion<ToolTaskResult, never> = { status: "completed", result: { entry, ...(result.control === undefined ? {} : { control: result.control }) } };
		return completion;
	};
}

function toMessage(call: ToolCall, result: ToolResult, now: number): ToolResultMessage {
	return { role: "toolResult", toolCallId: call.id, toolName: call.name, content: result.content ?? [], isError: result.isError ?? false, timestamp: now } as ToolResultMessage;
}

function bound(result: ToolResult, declared: ToolDeclaration["output"]): { result: ToolResult; truncated?: { bytes: number; lines: number } } {
	const b = { ...DEFAULT_BOUNDS, ...declared };
	let droppedBytes = 0;
	let droppedLines = 0;
	const content = (result.content ?? []).map((block) => {
		if (block.type !== "text") return block;
		let text = block.text;
		const lines = text.split("\n");
		if (lines.length > b.maxLines) { droppedLines += lines.length - b.maxLines; text = (b.retain === "head" ? lines.slice(0, b.maxLines) : lines.slice(-b.maxLines)).join("\n"); }
		const bytes = new TextEncoder().encode(text);
		if (bytes.length > b.maxBytes) { droppedBytes += bytes.length - b.maxBytes; text = new TextDecoder().decode(b.retain === "head" ? bytes.subarray(0, b.maxBytes) : bytes.subarray(-b.maxBytes)); }
		return { ...block, text };
	});
	if (droppedBytes === 0 && droppedLines === 0) return { result };
	const note = { severity: "warn" as const, code: "truncated", message: `output truncated: ${droppedLines} lines, ${droppedBytes} bytes dropped` };
	return { result: { ...result, content, diagnostics: [...(result.diagnostics ?? []), note] }, truncated: { bytes: droppedBytes, lines: droppedLines } };
}

export type { S };
