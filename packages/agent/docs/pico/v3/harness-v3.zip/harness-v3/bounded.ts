/**
 * Bounded byte collector: keeps at most `max` bytes from the head or tail and
 * counts what it dropped. Push is O(chunk). Owned by the kernel (pi.tool);
 * tools never bound their own output.
 */
export class Bounded {
	private chunks: Uint8Array[] = [];
	private kept = 0;
	dropped = 0;
	total = 0;
	constructor(private readonly max: number, private readonly retain: "head" | "tail") {}
	push(chunk: Uint8Array) {
		this.total += chunk.length;
		if (this.retain === "head") {
			if (this.kept >= this.max) { this.dropped += chunk.length; return; }
			const take = Math.min(chunk.length, this.max - this.kept);
			this.chunks.push(take === chunk.length ? chunk : chunk.subarray(0, take));
			this.kept += take;
			this.dropped += chunk.length - take;
			return;
		}
		this.chunks.push(chunk);
		this.kept += chunk.length;
		while (this.chunks.length > 1 && this.kept - this.chunks[0]!.length >= this.max) {
			const drop = this.chunks.shift()!;
			this.kept -= drop.length;
			this.dropped += drop.length;
		}
	}
	text(): string {
		const total = this.chunks.reduce((n, c) => n + c.length, 0);
		const all = new Uint8Array(total);
		let o = 0;
		for (const c of this.chunks) { all.set(c, o); o += c.length; }
		let s = new TextDecoder().decode(all);
		if (this.retain === "tail" && all.length > this.max) s = new TextDecoder().decode(all.subarray(all.length - this.max));
		return s;
	}
}
