// A scripted provider so the examples run without keys. Replace with pi-ai's builtinModels().
import { fake, type Response } from "../test/helpers.ts";
import type { RequestMessage } from "../types.ts";

export function scriptedModels(tokenDelayMs = 8) {
	return fake({
		tokenDelayMs,
		respond(messages: RequestMessage[]): Response {
			const last = [...messages].reverse().find((m) => m.role !== "system")!;
			if (last.role === "toolResult") return { text: "The command ran. Here is what I found: the tests pass and the tree is clean." };
			const user = String((last as { content?: unknown }).content ?? "");
			if (user.includes("Respond with the summary only")) return { text: "Summary: we discussed the repo and ran a shell command." };
			if (user.startsWith("run:")) return { toolCalls: [{ name: "bash", arguments: { command: user.slice(4) } }] };
			if (user.startsWith("delegate:")) return { toolCalls: [{ name: "delegate", arguments: { v: user.slice(9) } }] };
			if (user.startsWith("build")) return { toolCalls: [{ name: "build", arguments: { v: "all" } }] };
			if (user.startsWith("child task")) return { text: `As a subagent I looked into "${user.slice(11)}" and found nothing alarming.` };
			return { text: `You said "${user}". I am a scripted model streaming a few words back to you.` };
		},
	});
}
