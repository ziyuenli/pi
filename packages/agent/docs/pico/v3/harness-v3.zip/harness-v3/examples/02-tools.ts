// A bash tool, a running-tools view, a follow-up queued while busy, and a manual compaction.
import { BACKGROUND_CONTEXT as ctx } from "@earendil-works/chord/context";
import { bashTool } from "../bash.ts";
import { Harness, applyDelta, type ConversationView, kinds } from "../harness.ts";
import { MemoryStorage } from "../memory.ts";
import { scriptedModels } from "./fake.ts";

const h = await Harness.open(new MemoryStorage(), {
	models: scriptedModels(2),
	tools: [bashTool({ maxBytes: 2000, retain: "tail" })],
	root: { rewindable: { model: { provider: "anthropic", modelId: "fake-1" }, selectedTools: ["bash"], keepRecent: 40 } },
}, ctx);
h.hooks(kinds.tool, { beforeTool: (call) => (String((call.arguments as { command: string }).command).includes("rm ") ? { block: "no deleting" } : undefined) });
h.resume();
const c = await h.root(ctx);

// What a UI renders, as a pure function of the view.
function render(v: ConversationView) {
	const lines: string[] = [];
	for (const e of v.entries) lines.push(`  ${e.kind.padEnd(16)} ${e.head ? "[head] " : ""}${summary(e)}`);
	if (v.sticky.turn.message) lines.push(`  ~ streaming: ${summary({ model: [v.sticky.turn.message] })}`);
	for (const t of v.sticky.turn.tools) lines.push(`  ~ tool ${t.name}(${JSON.stringify(t.args)}): ${(t.output ?? "").split("\n").length} lines so far`);
	for (const q of v.sticky.inbox) lines.push(`  ? queued [${q.mode}] ${q.mode === "write" ? q.entry.kind : String(q.input)}`);
	lines.push(`  ${v.tasks.some((t) => !t.background) ? "working…" : "idle"}`);
	return lines.join("\n");
}
const summary = (e: { model?: unknown[] }) => {
	const m = e.model?.[0] as { role?: string; content?: unknown } | undefined;
	if (!m) return "";
	const c = typeof m.content === "string" ? m.content : JSON.stringify(m.content);
	return `${m.role}: ${c.slice(0, 60)}`;
};

const w = await c.watch(ctx);
let view = w.view;
w.start((d) => { view = applyDelta(view, d); });

const a = await c.send({ content: "run:ls -la /tmp | head -20" }, ctx);
await new Promise((r) => setTimeout(r, 60));
console.log("--- mid-turn ---\n" + render(view));
const f = await c.send({ content: "and what about /etc?" }, ctx);          // busy → followUp
console.log("\n--- follow-up queued ---\n" + render(view));
await a.wait(ctx);
await f.wait(ctx);
await c.waitForIdle(ctx);
console.log("\n--- both answered ---\n" + render(view));

const blocked = await c.send({ content: "run:rm -rf /" }, ctx);
await blocked.wait(ctx);
const last = view.entries.filter((e) => e.kind === "pi.tool_result").pop()!;
console.log("\n--- blocked by hook ---\n  " + summary(last));

const cid = await c.collapse("Keep the commands that were run.", ctx);
for (;;) { const t = await c.commit((tx) => tx.task(cid), ctx); if (t?.status === "terminal") break; await new Promise((r) => setTimeout(r, 10)); }
await new Promise((r) => setTimeout(r, 20));
console.log("\n--- after compaction (view holds the active transcript only) ---\n" + render(view));

w.stop();
await h.close(ctx);
