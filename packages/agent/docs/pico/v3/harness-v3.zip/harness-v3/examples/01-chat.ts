// Open a session on disk, watch it, send a message, change the model, close. Run it twice.
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { BACKGROUND_CONTEXT as ctx } from "@earendil-works/chord/context";
import { Harness, applyDelta, kinds } from "../harness.ts";
import { JsonlStorage } from "../jsonl.ts";
import { systemSections } from "../system.ts";
import { scriptedModels } from "./fake.ts";

const dir = process.argv[2] ?? mkdtempSync(join(tmpdir(), "chat-"));
const h = await Harness.open(await JsonlStorage.open(dir), {
	models: scriptedModels(),
	root: { rewindable: { model: { provider: "anthropic", modelId: "fake-1" } } },
}, ctx);
h.hooks(kinds.generation, { systemInstructions: ({ sections }) => { sections.set(systemSections.identity, "You are terse."); } });
h.resume();
const c = await h.root(ctx);

const w = await c.watch(ctx);
let view = w.view;
console.log(`session ${dir}: ${view.entries.length} entries so far`);
w.start((d) => {
	view = applyDelta(view, d);
	const streaming = view.sticky.turn.message?.content[0];
	if (streaming && streaming.type === "text") process.stdout.write(`\r${streaming.text.padEnd(90)}`);
	for (const e of d.entries) if (e.kind === "pi.assistant") process.stdout.write("\n");
});

const input = await c.send({ content: "hello there", requestId: `turn-${view.entries.length}` }, ctx);
const r = await input.wait(ctx);
console.log(`→ ${r.status}, answered by entry ${r.answer}`);

await c.commit((tx) => { tx.rewindable(c.id).model = { provider: "anthropic", modelId: "fake-2" }; }, ctx);
console.log("model now:", (await c.rewindable(ctx)).model?.modelId);

w.stop();
await h.close(ctx);
console.log(`run again with: tsx --tsconfig tsconfig.json examples/01-chat.ts ${dir}`);
