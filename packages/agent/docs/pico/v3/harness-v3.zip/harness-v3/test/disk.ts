import { readFileSync } from "node:fs";
import { join } from "node:path";
import { Type } from "@sinclair/typebox";
import type { ToolDeclaration } from "../types.ts";
import { ctx, fake, lastMessage, model, open } from "./helpers.ts";
import { systemSections } from "../system.ts";
import { kinds } from "../harness.ts";

const words = "the quick brown fox jumps over the lazy dog and keeps running through the forest until night falls".split(" ");
const text = (n: number, seed: number) => Array.from({ length: n }, (_, i) => words[(i * 7 + seed) % words.length]).join(" ");

const grep: ToolDeclaration = { name: "grep", description: "search", parameters: Type.Object({ v: Type.String() }), async execute(_a, api) { api.stream(text(300, 3)); return {}; } };
const env = await open({
	backend: "jsonl",
	tools: [grep],
	models: fake({ respond: (m, call) => (lastMessage(m).role === "toolResult" ? { text: text(150, call) } : call % 2 === 0 ? { text: text(20, call), toolCalls: [{ name: "grep", arguments: { v: "x" } }] } : { text: text(200, call) }) }),
	root: { rewindable: { model, selectedTools: ["grep"] } },
});
env.h.hooks(kinds.generation, { systemInstructions: ({ sections }) => { sections.set(systemSections.identity, text(120, 1)); } });

const N = 100;
const t0 = performance.now();
for (let i = 0; i < N; i++) await (await env.root.send({ content: `turn ${i}: ${text(15, i)}` }, ctx)).wait(ctx);
await env.root.waitForIdle(ctx);
console.log(`${N} turns (every other with a tool call) in ${(performance.now() - t0).toFixed(0)}ms`);

const main = readFileSync(join(env.dir!, "main.jsonl"), "utf8");
const lines = main.split("\n").filter(Boolean);
const by = new Map<string, { n: number; bytes: number }>();
let entryBytesByKind = new Map<string, number>();
for (const line of lines) {
	const r = JSON.parse(line) as { writes: { type: string; task?: { kind: string; status: string; checkpoint?: { phase: string } }; patch?: { status?: string; checkpoint?: { phase: string }; outcome?: unknown }; entry?: { kind: string }; input?: { status: string }; ref?: { doc: string } }[] };
	for (const w of r.writes) {
		const key =
			w.type === "task" ? `task.create.${w.task!.kind.replace("pi.", "")}` :
			w.type === "task.patch" ? `task.patch:${w.patch!.status ?? "-"}${w.patch!.checkpoint ? "@" + w.patch!.checkpoint.phase : w.patch!.outcome ? "+outcome" : ""}` :
			w.type === "entry" ? `entry.${w.entry!.kind.replace("pi.", "")}` :
			w.type === "input" ? `input:${w.input!.status}` :
			w.type === "doc" ? `doc.${w.ref!.doc}` : w.type;
		const bytes = JSON.stringify(w).length;
		const cur = by.get(key) ?? { n: 0, bytes: 0 };
		by.set(key, { n: cur.n + 1, bytes: cur.bytes + bytes });
	}
}
const total = [...by.values()].reduce((n, v) => n + v.bytes, 0);
console.log(`\nmain.jsonl: ${(main.length / 1024).toFixed(0)}KB, ${lines.length} records, ${[...by.values()].reduce((n, v) => n + v.n, 0)} writes`);
console.log(`sticky-1.jsonl: ${(readFileSync(join(env.dir!, "sticky-1.jsonl")).length / 1024).toFixed(1)}KB`);
console.log(`files in dir: ${(await import("node:fs")).readdirSync(env.dir!).join(", ")}`);
console.log(`tasks in memory: ${(await env.tasks()).length} of ${N * 2.5} ever created\n`);
console.log("write type".padEnd(40), "count".padStart(6), "KB".padStart(8), "%".padStart(6), "avg B".padStart(7));
for (const [k, v] of [...by].sort((a, b) => b[1].bytes - a[1].bytes)) console.log(k.padEnd(40), String(v.n).padStart(6), (v.bytes / 1024).toFixed(1).padStart(8), ((100 * v.bytes) / total).toFixed(1).padStart(6), Math.round(v.bytes / v.n).toString().padStart(7));
const taskBytes = [...by].filter(([k]) => k.startsWith("task.")).reduce((n, [, v]) => n + v.bytes, 0);
const entryBytes = [...by].filter(([k]) => k.startsWith("entry.")).reduce((n, [, v]) => n + v.bytes, 0);
console.log(`\ntasks: ${(100 * taskBytes / total).toFixed(0)}%   entries: ${(100 * entryBytes / total).toFixed(0)}%   per turn: ${(main.length / N / 1024).toFixed(1)}KB`);
console.log("DIR", env.dir); await env.h.close(ctx);
