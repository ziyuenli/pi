# A durable agent harness in ~3k lines

## Why pico failed

Pico modelled every durable thing as its own object with its own lifecycle:
tasks with checkpoints, outputs with deltas, inputs with results, requests with
receipts, addresses with scopes, entries with facets. Each got a transaction
surface, a capability brand, and an exactness type. The result is that a core
kind spends most of its lines negotiating with the kernel instead of doing
domain work, and the five kinds together came to 1,570 lines plus 374 of
surfaces that had to be invented to make them compile.

The tell was the casts. Every `as unknown as` marked a place where the
abstraction didn't carry what the code needed. There were dozens.

The deeper mistake: pico treated *durable operation state* as the primary
thing, and the transcript as one output of it. That's backwards. The
transcript is the primary thing. Everything else can be derived from it.

## The one idea

**One append-only event log per session. All state is a fold over it. Recovery
is: fold, then continue.**

```
open:     state = fold(readLog())
run:      loop { look at state; do the next obvious thing; append what happened }
crash:    nothing to do
reopen:   state = fold(readLog())   ← same as open
          run                        ← the loop sees what's in flight and continues
```

There are no tasks, no checkpoints, no phases, no `execute`/`recover` pair, no
scoped state, no transaction surfaces, no capability brands. There is a log, a
fold, and a loop.

This is not Temporal-style replay. We never re-execute code to reconstruct
state; we fold *data*. Determinism is not required. A hook can do anything it
likes because it doesn't get re-run to rebuild state.

---

## The log

```ts
type Event =
  // transcript
  | { t: "user";      c: Id; id: Id; content: UserInput; mode?: "steer" | "followUp"; requestId?: string }
  | { t: "assistant"; c: Id; id: Id; message: AssistantMessage; attempt: number }
  | { t: "tool_result"; c: Id; id: Id; callId: string; message: ToolResultMessage; control?: ToolControl }
  | { t: "system";    c: Id; id: Id; message: SystemMessage }          // rendered prompt + tool loadout, when it changed
  | { t: "notice";    c: Id; id: Id; content: string }
  | { t: "summary";   c: Id; id: Id; through: Id; text: string }        // context restarts here
  | { t: "reset";     c: Id; id: Id }                                    // context restarts here, empty
  // in-flight markers (what the loop needs to know after a crash)
  | { t: "generating"; c: Id; id: Id; attempt: number; requestKey: string }
  | { t: "tool_started"; c: Id; id: Id; callId: string; call: ToolCall; replay: "safe" | "unsafe" }
  | { t: "job_started"; c: Id; id: Id; key: string; spec: ProcessSpec; notify: boolean }
  | { t: "job_exited"; c: Id; id: Id; key: string; exitCode: number }
  | { t: "subagent_started"; c: Id; id: Id; callId: string; child: Id }
  // control
  | { t: "config";    c: Id; id: Id; key: string; value: JsonValue }
  | { t: "abort";     c: Id; id: Id }
  | { t: "fork";      c: Id; id: Id; from: Id; at: Id }                  // this conversation starts as `from` up to `at`
  | { t: "plugin";    c: Id; id: Id; kind: string; data: JsonValue };   // anything a plugin wants durable
```

`c` is the conversation, `id` is a session-wide monotonic sequence. That's the
only ID space. Fifteen event types. Nothing else is durable.

Storage is one JSONL file (or one SQLite table with `(id, c, json)`). Append is
the only write. `open` reads it all. A session of 10k events is a few MB and
folds in milliseconds; snapshot the fold to a sidecar later if it ever matters.

**Not in the log:** streaming partials, tool progress, inbox lists, input
results, request receipts, task records, checkpoints, output deltas. Every one
of those is either ephemeral (streaming) or derivable (everything else).

---

## The fold

```ts
interface Conversation {
  id: Id;
  parent?: { from: Id; at: Id };
  entries: Entry[];                        // transcript in order: user/assistant/tool_result/system/notice/summary/reset
  config: Map<string, JsonValue>;          // current values; rewind = fold up to `at`
  inflight: {
    generation?: { id: Id; attempt: number; requestKey: string };
    tools: Map<string, { id: Id; call: ToolCall; replay: "safe" | "unsafe"; subagent?: Id }>;
    jobs: Map<string, { id: Id; spec: ProcessSpec; notify: boolean }>;
  };
  queued: { id: Id; mode: "steer" | "followUp"; content: UserInput }[];
  aborted: boolean;
}

function fold(events: Event[], upTo?: Id): Map<Id, Conversation>
```

Rules, all of them:

- `user` with no `mode`, or placed by the loop: transcript entry. With `mode` and
  the conversation is mid-turn at that point: goes to `queued`.
- `assistant` clears `inflight.generation` and, if it has tool calls, opens
  `inflight.tools` for each.
- `tool_result` closes its `inflight.tools` entry.
- `generating` sets `inflight.generation`. `tool_started` records replay policy
  and the final call. `subagent_started` attaches a child conversation to a tool.
- `summary`/`reset`: transcript entry; `context()` starts from here.
- `config`: `config.set(key, value)`.
- `abort`: `aborted = true`; cleared by the next `user`.
- `fork`: initialise from `fold(parent, at)`.

`context(conversation)` walks `entries` from the last `summary`/`reset`,
reorders tool results into call order, synthesises a missing result for any
call whose result never landed before a `fork`. That's §1.3 in one function.

The fold is a pure function. It's also the *only* place event semantics live.
Every consumer — the loop, the watch, the public API, tests — reads the same
struct.

---

## The loop

One per conversation. Started by `open` for every conversation whose fold has
something in flight or queued, and by `send`.

```ts
async function run(conv: Conversation, ctx: Context) {
  while (true) {
    if (conv.aborted) return await finishAborted(conv);

    // 1. Tools in flight? Run (or resume) them concurrently.
    if (conv.inflight.tools.size > 0) {
      await Promise.all([...conv.inflight.tools.values()].map(t => runTool(conv, t, ctx)));
      continue;                                   // fold updated by appends; re-check
    }

    // 2. Last assistant message had tool calls, all results in? Or steer queued? → generate.
    // 3. Last entry is a user message (or placed followUp)? → generate.
    // 4. Otherwise: final answer reached. Place followUps if any → generate; else return.
    const next = decideNext(conv);                 // ~20 lines of pure logic over conv.entries + conv.queued
    if (next === "idle") return;
    if (next === "place") { await placeQueued(conv, "all"); continue; }
    await generate(conv, ctx);
  }
}
```

`generate`:

```ts
async function generate(conv, ctx) {
  const attempt = (conv.inflight.generation?.attempt ?? 0) + 1;
  if (!conv.inflight.generation) await append({ t: "generating", attempt, requestKey: uuid() });

  const request = await buildRequest(conv, ctx);                   // system prompt, tools, hooks; below
  if (overflow(request)) return await compactAndRetry(conv, ctx);

  const live = watch.streaming(conv.id);                          // in-memory partial, not durable
  for await (const event of models.stream(request, ctx)) live.apply(event);
  const message = live.final();

  await hooks.afterResponse(message);
  if (message.stopReason === "error" && retryable(message, attempt)) {
    await sleep(backoff(attempt), ctx);
    return;                                                        // loop re-enters generate; attempt+1
  }
  await append({ t: "assistant", message, attempt });
  if (message.usage && overThreshold(conv, message.usage)) queueCompaction(conv);
}
```

`runTool`:

```ts
async function runTool(conv, t, ctx) {
  const tool = registry.get(t.call.name);
  if (!t.started) {                                                // fold says no tool_started yet
    const call = await hooks.beforeTool(t.call);                   // may block → synthetic error result
    await append({ t: "tool_started", callId: call.id, call, replay: tool.replay });
  } else if (t.replay !== "safe" || tool.replay !== "safe") {
    return append(errorResult(t.call, "interrupted"));
  }
  const result = await tool.execute(t.call.arguments, facade(conv, t), ctx);
  await append({ t: "tool_result", callId: t.call.id, message: toMessage(result), control: result.control });
}
```

That's the whole turn machine. Post-tools folding (`addTools`, `terminate`,
`handoff`) is fifteen lines inside `decideNext`.

**Recovery is free.** Reopen → fold → `run`. If the log ends with `generating`
and no `assistant`, `generate` runs again with `attempt + 1` (the request key
tells you it's a retry). If it ends with `tool_started` and no `tool_result`,
`runTool` checks replay policy. If a subagent conversation exists with no
terminal state, its own loop resumes. There is no `recover()` because the loop
never assumes anything the fold doesn't say.

---

## Streaming and watch

The fold state is wrapped in one Chord tracker per session. Every `append`
updates the fold and flushes a delta. Streaming partials are applied to a
`streaming: Map<Id, AssistantMessage>` field on the same tracked object and
flushed on a 50ms timer. Watchers get one delta stream that contains both
durable and ephemeral state, and can't tell the difference — nor should they.

Chord is used for exactly what it's good at (diffing an in-memory object into
deltas for observers) and nothing else. It's not in the durability path.

After a crash, the partial is gone. The fold shows `generating` without
`assistant`, the loop re-requests, the watcher sees a new stream start. That
is also exactly what pico did on recovery of `requesting` — it just paid a
per-token commit for a partial it then threw away.

---

## Everything else, mapped

| pico concept | here |
|---|---|
| scoped state, addresses, `value`/`list`, rewind | `config` events; rewind is `fold(events, at)` |
| `TaskOutput`, `pi.output` list, per-token deltas | in-memory `streaming` on the watch tracker |
| inbox, `pi.input_result`, `pi.request`, `InputHandle` | `queued` in the fold; `wait(inputId)` resolves when an `assistant` with `id > inputId` lands and the conversation is idle; `requestId` dedup is a set check on append |
| boundaries (final-answer / post-tools / idle) | `decideNext` + `placeQueued(conv, "steer" \| "all")` |
| `pi.summary` head facet, `pi.reset`, `pi.handoff` | `summary` / `reset` events; `context()` starts at the last one |
| §12 sections, drafts, baseline/delta, canonical fold | `systemPrompt: (conv) => { text, tools }` — a function. `buildRequest` calls it, compares with the last `system` event, appends a new one if different. Baseline-vs-delta is `if (changed)`. |
| hook folds (`collect`/`first`/`chain`), `onThrow` policies | arrays of async functions called in order; errors propagate; `beforeTool` returns `{ block }` to stop |
| `pi.job`, `ProcessHost`, `waiting`/`spawning`/`running` | `job_started`/`job_exited` events; on reopen, `host.status(key)` for each started-not-exited |
| subagents, ownership, seeding, `abortWithTool` | a tool appends `subagent_started { child }`, creates child conversation with a `fork`/config events, awaits its loop. Abort propagates by appending `abort` to the child. |
| forks, `parent.at` | `fork` event; fold initialises from the parent up to `at` |
| plugin tasks, `defineTask`, plugin state | plugins append `plugin` events and read `conv.plugin[kind]` from the fold. They don't get a loop; if they need long-running work, that's a job. |
| commit line, read-before-write, 7 tx surfaces | `append(event)` under one session mutex. That's the line. |
| capability brands, `NoExtra`, `ExactJsonInput`, `DisjointBundles` | none. Tools get a narrow `facade`; everything internal is one module. |
| `Storage` interface, 9 write types, scans, `newestHead` | `append(e)`, `readAll()`. Two methods. |
| `execute`/`recover`/`abort`, `defineStateTask`, `Carry`, phases | the loop |

---

## What is genuinely dropped

- **Partial-response display after a crash.** The user sees the stream restart
  instead of the half-message. Acceptable.
- **Generic durable task kinds for plugins.** Plugins get tools, hooks, custom
  events, and jobs. They don't get to define a new kind of durable operation
  with its own recovery. If that's ever needed, it's a second loop kind, not a
  framework.
- **Type-level exactness guarantees.** Extra fields in a tool input won't be a
  compile error. They'll be ignored.
- **Fine-grained write capabilities.** A hook could, in principle, call
  `append` if handed the session. Don't hand it the session.

None of these was load-bearing for the goal.

---

## Line budget

| module | lines |
|---|---|
| `log.ts` — event types, JSONL append/read, session mutex | 200 |
| `fold.ts` — `fold`, `context`, tool-result reordering, fork inheritance | 350 |
| `loop.ts` — `run`, `decideNext`, `generate`, `runTool`, `placeQueued`, retry/backoff, overflow | 550 |
| `prompt.ts` — `buildRequest`: system prompt function, tool loadout, `system` event diff, hooks | 150 |
| `compact.ts` — `chooseThrough`, summariser call, `summary` append, threshold check | 150 |
| `tools.ts` — registry, validation, facade, output bounding, synthetic results | 250 |
| `subagent.ts` + `jobs.ts` — child conversations, process host polling | 300 |
| `watch.ts` — tracker over fold state + streaming, timer flush, subscribe | 150 |
| `session.ts` — open/close/abort, `send`, `wait`, `fork`, public handles | 400 |
| **total** | **~2500** |

That's with room for tests to be as long as the code.

---

## What makes it simple, in one sentence each

- **One ID space.** Sequence numbers. No `Id` vs `Seq`, no element IDs, no request keys as identities.
- **One write.** `append`. No write types, no validation table, no pre-persistence assertions.
- **One reader.** `fold`. Every consumer sees the same struct.
- **One executor.** `run`. No kinds, no scheduler, no eligibility rules, no dependency graphs.
- **Recovery is not a code path.** It's what `run` does when the fold has things in flight.
- **Durable = in the log. Ephemeral = not.** No third category.

The lane harness and pico both built a general durable-workflow engine and then
implemented an agent loop on top of it. This builds the agent loop and makes it
durable by writing down what it did.
