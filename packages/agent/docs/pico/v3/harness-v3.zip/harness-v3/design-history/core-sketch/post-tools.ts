import type { ToolCall, ToolResultMessage } from "@earendil-works/pi-ai";
import type { BoundaryTx, TranscriptReads } from "./assumed.ts";
import { generationConfig, postToolsConfig } from "./config.ts";
import type { Id, JsonObject, Stored } from "./core.ts";
import type { ToolControl } from "./entries.ts";
import { defineCoreTask } from "./tasks.ts";
import type { CoreFinalTx } from "./runtime.ts";
import { generationKind } from "./generation.ts";
import { type ToolTaskResult, toolKind } from "./tool.ts";
import { assistantEntry, handoffEntry, postToolsHooks, toolResultEntry } from "./witnesses.ts";

// ---------------------------------------------------------------------------
// Types (§10.3)
// ---------------------------------------------------------------------------

export interface PostToolsInput extends JsonObject {
	readonly inputs: readonly Id[];
	readonly assistant: Id;
	readonly tools: readonly Id[];
}
export type PostToolsCheckpoint = never;
export interface PostToolsResult extends JsonObject {
	readonly successor?: Id;
	readonly ended?: "terminate" | "handoff";
}
export type PostToolsFailure = never;
export type PostToolsAborted = null;

type Snapshot = {
	readonly call: ToolCall;
	readonly taskId: Id;
	readonly resultEntry: Id | undefined;
	readonly control: ToolControl | undefined;
	readonly missing: "orphaned" | "aborted" | undefined;
};

// ---------------------------------------------------------------------------
// The kind
// ---------------------------------------------------------------------------

export const postToolsKind = defineCoreTask<PostToolsInput, PostToolsCheckpoint, PostToolsResult, PostToolsFailure, PostToolsAborted>()({
	kind: "pi.post_tools",
	config: postToolsConfig,
	hooks: postToolsHooks,

	async execute(task, rt, ctx) {
		// Read-only snapshot of the terminal tool tasks and their result entries.
		// Terminal records never change, so this cannot go stale.
		const snapshot = await rt.commit(async (tx) => {
			const assistant = await tx.getEntry(assistantEntry, task.input.assistant);
			if (assistant === undefined) throw new Error("assistant entry missing"); // Pico wrote it: fault
			const calls = (assistant.model[0].content as unknown as ToolCall[]).filter((c) => c.type === "toolCall");
			const tasks = await tx.getTasks(task.input.tools);

			const rows: Snapshot[] = [];
			for (const [i, taskId] of task.input.tools.entries()) {
				const t = tasks.get(taskId);
				if (t === undefined || t.status !== "terminal") throw new Error(`tool task ${taskId} not terminal`); // after: guarantees terminal
				const call = calls[i]!;
				if (t.outcome.status === "completed") {
					const r = t.outcome.result as ToolTaskResult;
					rows.push({ call, taskId, resultEntry: r.entry, control: r.control, missing: undefined });
				} else if (t.outcome.status === "aborted") {
					const a = t.outcome.result as { entry?: Id };
					rows.push({ call, taskId, resultEntry: a.entry, control: undefined, missing: a.entry === undefined ? "aborted" : undefined });
				} else {
					rows.push({ call, taskId, resultEntry: undefined, control: undefined, missing: "orphaned" });
				}
			}
			return rows;
		}, ctx);

		// afterTools observes; it does not decide.
		await rt.hooks.run(
			postToolsHooks.afterTools,
			{ assistant: task.input.assistant, results: snapshot.map((s) => s.resultEntry).filter((e): e is Id => e !== undefined) },
			ctx,
		);

		return closure(task.input, snapshot, rt.now());
	},

	// No checkpoint: recover is execute.
	async recover(task, rt, ctx) {
		return this.execute(task, rt, ctx);
	},

	// post_tools owns the active group while live; a marked one must not strand placed inputs.
	async abort(task, _rt, _ctx) {
		return async (tx) => {
			(tx as unknown as BoundaryTx).resolveInputs(task.input.inputs, { status: "unanswered", reason: "aborted" });
			return null;
		};
	},
});

// ---------------------------------------------------------------------------
// Closure: §10.3 steps 1–7, in that exact order.
// ---------------------------------------------------------------------------

function closure(input: PostToolsInput, snapshot: readonly Snapshot[], now: number) {
	return async (tx: CoreFinalTx<PostToolsCheckpoint, never> & TranscriptReads & BoundaryTx, current: { conversationId: Id }) => {
		const conversationId = current.conversationId;

		// 1. Fresh selectedTools (a config change during afterTools must not be lost).
		const selectedTools = await tx.value(generationConfig.selectedTools).get();

		// 2. Fold control in call order.
		let addTools: string[] = [...selectedTools];
		let terminate = false;
		let handoff: string | undefined;
		for (const row of snapshot) {
			const c = row.control;
			if (c === undefined) continue;
			for (const name of c.addTools ?? []) if (!addTools.includes(name)) addTools.push(name);
			if (c.terminate) terminate = true;
			if (c.handoff !== undefined) handoff = c.handoff; // last in call order wins; handoff beats terminate
		}

		// 3. The only rewindable write, before any entry.
		if (addTools.length !== selectedTools.length) tx.value(generationConfig.selectedTools).set(addTools);

		// 4. Synthesized error results for orphaned/aborted-without-entry, in call order.
		for (const row of snapshot) {
			if (row.missing === undefined) continue;
			const message: ToolResultMessage = {
				role: "toolResult",
				toolCallId: row.call.id,
				toolName: row.call.name,
				content: [{ type: "text", text: `Tool result unavailable: task ${row.missing}.` }],
				isError: true,
				timestamp: now,
			} as ToolResultMessage;
			tx.entry(toolResultEntry, conversationId, {
				model: [message as Stored<ToolResultMessage>],
				data: { diagnostics: [{ severity: "error", message: `tool task ${row.missing}`, code: row.missing }] },
			});
		}

		// 5. Handoff head, directly, before anything else placed in this batch.
		if (handoff !== undefined) {
			tx.entry(handoffEntry, conversationId, {
				head: "self",
				model: [{ role: "user", content: handoff, timestamp: now }],
			});
		}

		// 6. Boundary.
		if (handoff !== undefined || terminate) {
			tx.resolveInputs(input.inputs, { status: "done", answer: input.assistant });
			const boundary = await tx.finalAnswerBoundary(conversationId);
			const ended = handoff !== undefined ? "handoff" : "terminate";
			if (boundary.triggers.length > 0) {
				const successor = tx.task(generationKind, { input: { inputs: boundary.triggers } });
				return { status: "completed" as const, result: { successor, ended } };
			}
			return { status: "completed" as const, result: { ended } };
		}

		const boundary = await tx.postToolsBoundary(conversationId);
		if (boundary.terminated) {
			// A placed self-head write ended the old group. Only triggers after the head start fresh.
			tx.resolveInputs(input.inputs, { status: "unanswered", reason: "terminated" });
			if (boundary.triggers.length > 0) {
				const successor = tx.task(generationKind, { input: { inputs: boundary.triggers } });
				return { status: "completed" as const, result: { successor } };
			}
			return { status: "completed" as const, result: {} };
		}
		// Ordinary continuation: group plus placed steer.
		const successor = tx.task(generationKind, { input: { inputs: [...input.inputs, ...boundary.triggers] } });
		return { status: "completed" as const, result: { successor } };

		// 7. Terminal snapshot is written by the kernel.
	};
}

// NOTES
//
// - `postToolsBoundary` must tell us `terminated` (a self-head write was
//   placed). Without it, step 6's second rule (§9.5) cannot be applied. This
//   is why the assumed helper returns that flag.
//
// - The snapshot pairs tool tasks with calls by index. That depends on
//   generation creating the tool tasks in call order, which it does.
