import type { AssistantMessage, ModelRef, RetryPolicy, ThinkingLevel, UserMessage } from "@earendil-works/pi-ai";
import { isRetryableAssistantError, retryDelayMs } from "@earendil-works/pi-ai";
import { defineEntry } from "./entries.ts";
import { defineHookPoint } from "./hooks.ts";
import { defineStateTask } from "./tasks.ts";
import type { Entry, Id, JsonObject, Stored } from "./core.ts";
import { generationKind } from "./generation.ts";
import { buildSummaryRequest, toolFree } from "./summarizer.ts";

// ---------------------------------------------------------------------------
// Assumed surfaces (see NOTES):
//   tx.readContext(conversationId, at?)  -> { head, entries }   [on the line]
//   actions.transition(phase, commit)    -> payload | completion
//   defineStateTask<I, Carry, C, ...>    -> task.carry, auto-threaded
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Entry kind
// ---------------------------------------------------------------------------

export interface SummaryEntry extends Entry {
  readonly kind: "pi.summary";
  readonly data: { readonly through: Id };
  readonly model: readonly [UserMessage];
  readonly head: Id;
}

export const summaryEntry = defineEntry<SummaryEntry>("pi.summary");

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export interface BeforeCollapseIn extends JsonObject {
  readonly reason: CollapseReason;
  readonly through: Id;
  readonly entries: readonly Entry[];
  readonly instructions?: string;
}

export type BeforeCollapseOut =
  | { readonly decline: true }
  | { readonly instructions: string }
  | { readonly summary: string }
  | undefined;

export const beforeCollapse = defineHookPoint<BeforeCollapseIn, BeforeCollapseOut>({
  name: "pi.before_collapse",
  fold: "first",
});

// ---------------------------------------------------------------------------
// Task types
// ---------------------------------------------------------------------------

export type CollapseReason = "threshold" | "manual" | "overflow";

export interface CollapseInput extends JsonObject {
  readonly reason: CollapseReason;
  readonly through: Id;
  readonly instructions?: string;
}

/** Carried unchanged across every phase; the adapter threads it. */
export interface CollapseCarry extends JsonObject {
  readonly expectedHead: Id | null;
  readonly instructions?: string;
  readonly model: ModelRef;
  readonly thinkingLevel: ThinkingLevel;
  readonly retry: Stored<RetryPolicy>;
  readonly attempt: number;
}

/** Per-phase payloads only. `carry` is not spelled here. */
export type CollapseCheckpoint =
  | { readonly phase: "summarizing" }
  | { readonly phase: "retrying"; readonly untilMs: number; readonly lastError: string }
  | { readonly phase: "prepared"; readonly summary: string };

export interface CollapseResult extends JsonObject {
  readonly summary: Id;
}

export interface CollapseFailure extends JsonObject {
  readonly reason: "stale" | "declined" | "provider" | "retries_exhausted" | "no_model";
  readonly detail: string;
}

export type CollapseAborted = null;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const fail = (reason: CollapseFailure["reason"], detail: string) =>
  ({ status: "failed", failure: { reason, detail } }) as const;

const summaryText = (message: AssistantMessage): string =>
  message.content
    .filter((block): block is Extract<typeof block, { type: "text" }> => block.type === "text")
    .map((block) => block.text)
    .join("");

// ---------------------------------------------------------------------------
// The kind
// ---------------------------------------------------------------------------

export const collapseKind = defineStateTask<
  CollapseInput,
  CollapseCarry,
  CollapseCheckpoint,
  CollapseResult,
  CollapseFailure,
  CollapseAborted
>()({
  kind: "pi.collapse",
  config: {
    model: generationKind.config.model,
    thinkingLevel: generationKind.config.thinkingLevel,
    retry: generationKind.config.retry,
  },
  hooks: { beforeCollapse },

  initial: {
    role: "start",
    async run(task, rt, actions, ctx) {
      const snapshot = await rt.commit(async (tx, current) => {
        const model = await tx.value(collapseKind.config.model).get();
        if (model === undefined) return null;
        const { head, entries } = await tx.readContext(current.conversationId, task.input.through);
        return {
          carry: {
            expectedHead: head?.id ?? null,
            ...(task.input.instructions === undefined ? {} : { instructions: task.input.instructions }),
            model,
            thinkingLevel: await tx.value(collapseKind.config.thinkingLevel).get(),
            retry: await tx.value(collapseKind.config.retry).get(),
            attempt: 1,
          } satisfies CollapseCarry,
          entries,
        };
      }, ctx);

      // No model terminalizes before the hook and before any checkpoint (§10.4).
      if (snapshot === null) return actions.terminal(() => fail("no_model", "no model configured"));

      const decision = await rt.hooks.run(
        "beforeCollapse",
        {
          reason: task.input.reason,
          through: task.input.through,
          entries: snapshot.entries,
          ...(snapshot.carry.instructions === undefined ? {} : { instructions: snapshot.carry.instructions }),
        },
        ctx,
      );

      if (decision !== undefined && "decline" in decision)
        return actions.terminal(() => fail("declined", "declined by beforeCollapse"));

      const carry: CollapseCarry =
        decision !== undefined && "instructions" in decision
          ? { ...snapshot.carry, instructions: decision.instructions }
          : snapshot.carry;

      // The hook ran off the line. Re-check the head in the same commit that
      // writes the checkpoint: a moved head means the hook decided against a
      // superseded context, and old entries must never pair with a new head.
      const summary = decision !== undefined && "summary" in decision ? decision.summary : undefined;
      const phase = summary === undefined ? "summarizing" : "prepared";

      return actions.transition(phase, carry, async (tx, current) => {
        const { head } = await tx.readContext(current.conversationId);
        if ((head?.id ?? null) !== carry.expectedHead) return fail("stale", "head moved during beforeCollapse");
        return summary === undefined ? {} : { summary };
      });
    },
  },

  phases: {
    // The provider call is in flight. `inflight` forces the recover arm.
    summarizing: {
      role: "inflight",

      async run(task, rt, actions, ctx) {
        const { carry } = task;

        // `through` is fixed by the input and everything at or below it is
        // immutable, so this read is reproducible and needs no line.
        const { entries } = await rt.readContext(task.conversationId, task.input.through);

        let message: AssistantMessage;
        try {
          // Request-local and tool-free (§10.4): every tool effective in the
          // projected history is removed and none are offered.
          message = await rt.models.complete(carry.model, toolFree(buildSummaryRequest(carry, entries)), {
            thinkingLevel: carry.thinkingLevel,
            signal: ctx.signal,
          });
        } catch (error) {
          return retry(carry, null, String(error), rt, actions);
        }

        if (message.toolCalls !== undefined && message.toolCalls.length > 0)
          return retry(carry, message, "summarizer returned tool calls", rt, actions);

        if (message.stopReason === "error")
          return retry(carry, message, message.errorMessage ?? "provider error", rt, actions);

        return actions.transition("prepared", carry, () => ({ summary: summaryText(message) }));
      },

      // The call may have happened and there is no result lookup. Count it as
      // this attempt's failure; never replay the same attempt number.
      async recover(task, rt, actions, _ctx) {
        return retry(task.carry, null, "interrupted", rt, actions);
      },
    },

    // Durable backoff. `start` means run and recover are one function: the
    // sleep is idempotent because `untilMs` is absolute.
    retrying: {
      role: "start",
      async run(task, rt, actions, ctx) {
        await rt.sleep(task.checkpoint.untilMs, ctx);
        return actions.transition("summarizing", { ...task.carry, attempt: task.carry.attempt + 1 }, () => ({}));
      },
    },

    // The candidate text is durable; only finalization remains. Never calls
    // the provider on recovery.
    prepared: {
      role: "start",
      async run(task, _rt, actions, _ctx) {
        const { summary } = task.checkpoint;
        const { expectedHead } = task.carry;
        const through = task.input.through;

        return actions.terminal(async (tx, current) => {
          // Head read first: someone else collapsing means our summary
          // describes a prefix that is no longer the prefix. Edits landing in
          // between carry no head and so do not stale.
          const { head, entries } = await tx.readContext(current.conversationId);
          if ((head?.id ?? null) !== expectedHead) return fail("stale", "head moved during collapse");

          // The summary's head is the first retained entry after the collapsed
          // prefix, so the summary appears and then the tail. Nothing retained
          // means context starts at the summary itself.
          const retained = entries.find((entry) => entry.id > through);

          const id = tx.entry(summaryEntry, current.conversationId, {
            data: { through },
            model: [{ role: "user", content: summary }],
            head: retained?.id ?? "self",
          });

          return { status: "completed", result: { summary: id } };
        });
      },
    },
  },

  // Collapse owns no external resource and creates no work; the partial
  // summary lives in the checkpoint and is retired with the task.
  async abort() {
    return async () => null;
  },
});

// ---------------------------------------------------------------------------
// Shared by `run` (provider failure) and `recover` (interruption). Records the
// attempt that failed; the next `summarizing` uses attempt + 1.
// ---------------------------------------------------------------------------
function retry(
  carry: CollapseCarry,
  message: AssistantMessage | null,
  detail: string,
  rt: { now(): number },
  actions: StateActions<CollapseCarry, CollapseCheckpoint, CollapseResult, CollapseFailure>,
) {
  // A null message is an interruption, which is always retryable in principle.
  if (message !== null && !isRetryableAssistantError(message)) return actions.terminal(() => fail("provider", detail));
  if (!carry.retry.enabled) return actions.terminal(() => fail("provider", detail));
  if (carry.attempt > carry.retry.maxRetries) return actions.terminal(() => fail("retries_exhausted", detail));

  const untilMs = rt.now() + retryDelayMs(carry.retry, carry.attempt);
  return actions.transition("retrying", carry, () => ({ untilMs, lastError: detail }));
}

// ---------------------------------------------------------------------------
// NOTES
//
// - `actions.transition(phase, carry, commit)` takes the carry explicitly
//   because two transitions change it (`retrying` -> `summarizing` bumps
//   `attempt`, and `initial` may replace `instructions`). Everywhere else it is
//   passed straight through, so an implicit default of "same carry" would
//   shorten three call sites. Explicit reads better: it is visible which
//   transitions mutate it.
//
// - `summarizing.run` reads off the line via `rt.readContext`; the two head
//   checks read on the line via `tx.readContext`. The distinction is exactly
//   "can another commit change this answer" — immutable prefix, no line;
//   current head, line.
//
// - §10.4 has no `retries_exhausted` reason, but §10.1 gives generation one and
//   the paths are otherwise identical. Added here; the spec should match.
// ---------------------------------------------------------------------------
