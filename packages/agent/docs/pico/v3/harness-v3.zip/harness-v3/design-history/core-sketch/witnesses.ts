import type { AssistantMessage, Message, ToolCall, ToolResultMessage, Usage } from "@earendil-works/pi-ai";
import type { ToolDeclaration, SystemSection } from "./assumed.ts";
import type { Id, JsonValue } from "./core.ts";
import {
	type AssistantEntry,
	defineEntry,
	type Entry,
	type HandoffEntry,
	type NoticeEntry,
	type SummaryEntry,
	type ToolResultEntry,
	type UsageEntry,
	type UserEntry,
} from "./entries.ts";
import { defineHookPoint } from "./hooks.ts";
import type { ToolResult } from "./tool.ts";

// ---------------------------------------------------------------------------
// Entry witnesses (§1.2). SystemEntry is owned by prepare.ts.
// ---------------------------------------------------------------------------

export const userEntry = defineEntry<UserEntry>("pi.user");
export const assistantEntry = defineEntry<AssistantEntry>("pi.assistant");
export const toolResultEntry = defineEntry<ToolResultEntry>("pi.tool_result");
export const noticeEntry = defineEntry<NoticeEntry>("pi.notice");
export const usageEntry = defineEntry<UsageEntry>("pi.usage");
export const summaryEntry = defineEntry<SummaryEntry>("pi.summary");
export const handoffEntry = defineEntry<HandoffEntry>("pi.handoff");

// ---------------------------------------------------------------------------
// Core hook points (§11.2 table). Declared on the kind that invokes them.
// ---------------------------------------------------------------------------

export interface SystemSectionDraft {
	get<T extends JsonValue>(section: SystemSection<T>): T | undefined;
	set<T extends JsonValue>(section: SystemSection<T>, value: T): void;
	delete(section: { readonly key: string }): void;
	wrap<T extends JsonValue>(section: SystemSection<T>, transform: (rendered: string) => string): void;
}

export type Settings = {
	readonly model?: { readonly provider: string; readonly modelId: string };
	readonly thinkingLevel: string;
	readonly selectedTools: readonly string[];
	readonly profile: string;
};

export const generationHooks = {
	systemInstructions: defineHookPoint<
		{ readonly sections: SystemSectionDraft; readonly config: Settings; readonly tools: readonly ToolDeclaration[] },
		{ readonly tools?: readonly ToolDeclaration[] }
	>({ fold: "collect", onThrow: "skip" }),

	beforeRequest: defineHookPoint<
		{ readonly request: { readonly messages: readonly Message[] }; readonly cutoff: Id },
		{ readonly request?: { readonly messages: readonly Message[] } }
	>({ fold: "chain", onThrow: "skip" }),

	onYield: defineHookPoint<{ readonly answer: AssistantMessage }, { readonly continue: string }>({
		fold: "first",
		onThrow: "skip",
	}),

	afterResponse: defineHookPoint<
		{ readonly message: AssistantMessage; readonly usage?: Usage; readonly attempt: number },
		void
	>({ fold: "collect", onThrow: "skip" }),
};

export const toolHooks = {
	beforeTool: defineHookPoint<
		{ readonly call: ToolCall; readonly block?: { readonly reason: string } },
		{ readonly call?: ToolCall; readonly block?: { readonly reason: string } }
	>({ fold: "chain", onThrow: "abort" }),

	afterTool: defineHookPoint<{ readonly call: ToolCall; readonly result: ToolResult }, { readonly result?: ToolResult }>({
		fold: "chain",
		onThrow: "skip",
	}),
};

export const postToolsHooks = {
	afterTools: defineHookPoint<{ readonly assistant: Id; readonly results: readonly Id[] }, void>({
		fold: "collect",
		onThrow: "skip",
	}),
};

export const collapseHooks = {
	beforeCollapse: defineHookPoint<
		{ readonly reason: "threshold" | "manual" | "overflow"; readonly through: Id; readonly entries: readonly Entry[] },
		{ readonly decline: true } | { readonly instructions?: string; readonly summary?: string }
	>({ fold: "first", onThrow: "skip" }),
};

// Re-exported for kinds that only need the type.
export type { ToolResultMessage };
