import type { Context } from "@earendil-works/chord";
import type { Op } from "@earendil-works/chord/delta";
import type {
	AssistantMessage,
	AssistantMessageEvent,
	DeferredHandle,
	Message,
	Model,
	Api,
	ToolCall,
	ImageContent,
	TextContent,
} from "@earendil-works/pi-ai";
import type { TSchema } from "@sinclair/typebox";

// ---------------------------------------------------------------------------
// JSON
// ---------------------------------------------------------------------------

export type JsonPrimitive = null | boolean | number | string;
export type JsonValue = JsonPrimitive | JsonObject | JsonValue[];
export interface JsonObject {
	[key: string]: JsonValue;
}
export type Id = number;
export type Seq = number;

// ---------------------------------------------------------------------------
// The four tables
// ---------------------------------------------------------------------------

export interface Conversation {
	readonly id: Id;
	readonly parent?: { readonly conversationId: Id; readonly at: Id };
	readonly owner?: Id; // task that created it
	/** §8.1 section seed: applied by preparation while the conversation has no local managed entry. */
	readonly sections?: import("./system.ts").SectionSeed[];
}

export type ContextEdit =
	| { readonly target: Id; readonly action: "omit" }
	| { readonly target: Id; readonly action: "replace"; readonly messages: RequestMessage[] };

export interface Entry {
	readonly id: Id;
	readonly conversationId: Id;
	readonly kind: string;
	readonly byTaskId?: Id;
	readonly data?: unknown;
	readonly model?: RequestMessage[];
	readonly head?: Id;
	readonly edits?: ContextEdit[];
}
export type NewEntry = Omit<Entry, "id" | "conversationId" | "byTaskId" | "head"> & { readonly head?: Id | "self" };

/** A typed witness for an entry kind: `is()` narrows, and typed writes take `EntryInput<E>`. */
export interface EntryKind<E extends Entry = Entry> {
	readonly kind: string;
	is(entry: Entry | undefined): entry is E;
}
export type EntryInput<E extends Entry> = Omit<E, "id" | "conversationId" | "kind" | "byTaskId" | "head"> &
	(E extends { readonly head: Id } ? { readonly head: Id | "self" } : { readonly head?: never });
export function defineEntry<E extends Entry>(kind: string): EntryKind<E> {
	return Object.freeze({ kind, is: (e: Entry | undefined): e is E => e?.kind === kind });
}

export type TaskStatus = "pending" | "running" | "terminal";
export type Outcome<R = unknown, F = unknown, A = unknown> =
	| { readonly status: "completed"; readonly result: R }
	| { readonly status: "failed"; readonly failure: F }
	| { readonly status: "aborted"; readonly result: A }
	| { readonly status: "orphaned" };

export interface Task<I = unknown, C extends Checkpoint = Checkpoint> {
	readonly id: Id;
	readonly conversationId: Id;
	readonly kind: string;
	readonly input: I;
	readonly status: TaskStatus;
	readonly checkpoint?: C;
	readonly after: Id[];
	readonly background?: true;
	readonly owns: Id[];
	readonly abort?: true;
	readonly outcome?: Outcome;
}
export type Checkpoint = { readonly phase: string };

export type InputMode = "steer" | "followUp" | "write";
export interface Input {
	readonly id: Id;
	readonly conversationId: Id;
	readonly requestId?: string;
	readonly status: "queued" | "placed" | "done" | "unanswered";
	readonly entry?: Id;
	readonly answer?: Id;
	readonly reason?: "terminated" | "aborted" | "failed" | "stale";
	readonly detail?: string;
}

// ---------------------------------------------------------------------------
// The three documents
// ---------------------------------------------------------------------------

export type ModelRef = { provider: string; modelId: string };
/** Structurally pi-ai's RetryPolicy; declared as an alias so it satisfies a document's index signature. */
export type RetryPolicy = { enabled: boolean; maxRetries: number; baseDelayMs: number; maxAgentDelayMs?: number };

// ---------------------------------------------------------------------------
// pi-ai PR #9116 shim. The spec's hard dependency; not landed. System
// instructions and the tool loadout ride inside `messages` as SystemMessage.
// ---------------------------------------------------------------------------
export interface SystemMessage {
	role: "system";
	content: string;
	toolsAdded?: { name: string; description: string; parameters: TSchema }[];
	toolsRemoved?: { name: string }[];
	timestamp: number;
}
export type RequestMessage = Message | SystemMessage;
export type ThinkingLevel = "off" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max";

/** Forks see this as it was at the fork point. (type aliases, not interfaces: documents must satisfy an index signature) */
export type RewindableState = {
	model?: ModelRef;
	thinkingLevel: ThinkingLevel;
	selectedTools: string[];
	profile: string;
	threshold: number;
	keepRecent: number;
	plugins: Record<string, unknown>;
	[key: string]: unknown; // ordinary kinds' declared config lives at the top level, keyed by the disjoint names
};

export type UserInput = string | (TextContent | ImageContent)[];
export type QueuedInput =
	| { id: Id; mode: "steer" | "followUp"; input: UserInput; requestId?: string }
	| { id: Id; mode: "write"; entry: NewEntry; requestId?: string };

/** One running tool call, at the index of its call in the assistant message. */
export type ToolSlot = {
	callId: string;
	name: string;
	args: unknown;
	output?: string; // bounded stream as it stands
	progress?: string;
	details?: unknown;
	continuedBy?: Id; // a background task that took the work over; its live state is `tasks[continuedBy]`
};

/** The current turn, shaped for rendering. Reset when a generation starts; cleared when the turn ends. */
export type TurnState = {
	message?: AssistantMessage; // streaming assistant message
	tools: ToolSlot[]; // tools of the assistant message being executed, by call index
};

/** The present. Never folded historically; truncated to its last base. */
export type StickyState = {
	retry: RetryPolicy;
	steeringMode: "all" | "one-at-a-time";
	followUpMode: "all" | "one-at-a-time";
	inbox: QueuedInput[];
	turn: TurnState;
	tasks: Record<string, object>; // non-turn tasks (jobs, plugin tasks) keyed by task id; retired by the kernel on terminal
	plugins: Record<string, unknown>;
	[key: string]: unknown;
};

export type SessionState = { plugins: Record<string, unknown> };

export const defaultRewindable = (): RewindableState => ({
	thinkingLevel: "off",
	selectedTools: [],
	profile: "default",
	threshold: 0,
	keepRecent: 20_000,
	plugins: {},
});
export const defaultSticky = (): StickyState => ({
	retry: { enabled: true, maxRetries: 3, baseDelayMs: 2000, maxAgentDelayMs: 60_000 },
	steeringMode: "one-at-a-time",
	followUpMode: "one-at-a-time",
	inbox: [],
	turn: { tools: [] },
	tasks: {},
	plugins: {},
});

export type DocRef = { doc: "session" } | { doc: "rewindable"; conversationId: Id } | { doc: "sticky"; conversationId: Id };

// ---------------------------------------------------------------------------
// Configuration facade: every registered kind's `config` merged flat. Which
// document a key lives in is the kernel's business; a caller just sets it.
// ---------------------------------------------------------------------------

type UnionToIntersection<U> = (U extends unknown ? (x: U) => void : never) extends (x: infer I) => void ? I : never;
type RewindableOf<K> = K extends unknown ? (ConfigOf<K> extends { readonly rewindable: infer RC } ? RC : {}) : never; // distributes over a union of kinds
type StickyOf<K> = K extends unknown ? (ConfigOf<K> extends { readonly sticky: infer SC } ? SC : {}) : never;
/** All keys declared by a set of kinds, merged. `model` is the one member with no default (`| undefined`). */
export type ConfigOfKinds<Ks extends readonly AnyKind[]> = UnionToIntersection<RewindableOf<Ks[number]> | StickyOf<Ks[number]>> extends infer M ? { [K in keyof M]: M[K] } : never;
/**
 * `true` iff no two kinds declare the same key (in either document). Each kind's keys
 * are tagged with the kind's tuple index; intersecting the tagged records makes a
 * colliding key's type `never`. Asserted at open and at compile time.
 */
type KeysOfKind<K> = (keyof RewindableOf<K> | keyof StickyOf<K>) & string;
type Tagged<Ks extends readonly AnyKind[]> = { [I in keyof Ks]: { [key in KeysOfKind<Ks[I]>]: I } }[number];
type Merged<Ks extends readonly AnyKind[]> = UnionToIntersection<Tagged<Ks>>;
export type DisjointConfig<Ks extends readonly AnyKind[]> = { [K in keyof Merged<Ks>]: [Merged<Ks>[K]] extends [never] ? K : never }[keyof Merged<Ks>] extends never ? true : false;

export interface ConfigFacade<Cfg extends object> {
	get(ctx: Context): Promise<Cfg>;
	set(patch: Partial<Cfg>, ctx: Context): Promise<void>; // one commit, routed to the right documents
}

// ---------------------------------------------------------------------------
// Storage: five writes, a handful of reads
// ---------------------------------------------------------------------------

export type TaskPatch = { id: Id } & Partial<Pick<Task, "status" | "checkpoint" | "abort" | "outcome" | "owns">>;
export type Write =
	| { type: "conversation"; conversation: Conversation }
	| { type: "entry"; entry: Entry }
	| { type: "task"; task: Task } // create
	| { type: "task.patch"; patch: TaskPatch } // status / checkpoint / abort / outcome / owns; `checkpoint: undefined` clears
	| { type: "input"; input: Input } // create or replace whole
	| { type: "doc"; ref: DocRef; ops: Op[] };

export interface EntryScan {
	conversationId: Id;
	kind?: string;
	withHead?: boolean;
	before?: Id; // exclusive upper bound
	limit: number;
}
export interface TaskScan {
	conversationId?: Id;
	kind?: string;
	status?: TaskStatus[];
	abort?: boolean;
}

export interface Storage {
	nextId(): Id;
	commit(writes: Write[], ctx: Context): Promise<Seq>;

	conversation(id: Id, ctx: Context): Promise<Conversation | undefined>;
	conversations(ctx: Context): Promise<Conversation[]>;

	entries(ids: Id[], ctx: Context): Promise<Map<Id, Entry>>;
	/** Fork-aware, newest first. */
	scanEntries(scan: EntryScan, ctx: Context): Promise<Entry[]>;

	task(id: Id, ctx: Context): Promise<Task | undefined>;
	scanTasks(scan: TaskScan, ctx: Context): Promise<Task[]>;
	/**
	 * Forget terminal tasks nobody depends on. A terminal task is kept only while a
	 * live task lists it in `after` (its outcome is read at dispatch); everything a
	 * terminal task did is already an entry. In-memory only: the on-disk history stays.
	 */
	pruneTerminal(ctx: Context): Promise<number>;

	input(id: Id, ctx: Context): Promise<Input | undefined>;
	inputByRequest(requestId: string, ctx: Context): Promise<Input | undefined>;

	/** Current document value (folded from its last base). */
	doc(ref: DocRef, ctx: Context): Promise<JsonValue | undefined>;
	/** Rewindable only: value as of the end of the commit containing entry `at`. */
	docAsOf(conversationId: Id, at: Id, ctx: Context): Promise<JsonValue | undefined>;
	/** Sticky only: drop ops before the last base. */
	truncate(ref: DocRef, ctx: Context): Promise<void>;

	close(ctx: Context): Promise<void>;
}

// ---------------------------------------------------------------------------
// Kinds
// ---------------------------------------------------------------------------

export type Completion<R = unknown, F = unknown> =
	| { readonly status: "completed"; readonly result: R }
	| { readonly status: "failed"; readonly failure: F };

/**
 * Closures receive the erased `Task`: the kind's own typed `task` is already in
 * scope where the closure is built. Keeping `I`/`C` out of the closure type is
 * what lets every Kind<...> sit in one registry without a witness or a cast.
 */
export type Closure<R, F> = (tx: Tx, current: Task) => Completion<R, F> | Promise<Completion<R, F>>;
export type AbortClosure<A> = (tx: Tx, current: Task) => A | Promise<A>;

/**
 * What a phase handler returns: advance to a checkpoint, or finish.
 * `next` may be a builder that runs on the line — to append entries atomically
 * with the checkpoint, or to terminalize instead after a check.
 */
export type Step<C extends Checkpoint, R, F> =
	| { readonly next: C | ((tx: Tx, current: Task) => C | Completion<R, F> | "retry" | Promise<C | Completion<R, F> | "retry">) }
	| { readonly done: Closure<R, F> };

export type CheckpointAt<C extends Checkpoint, P extends C["phase"]> = Extract<C, { readonly phase: P }>;

/**
 * A phase handler is invoked by the scheduler when it dispatches a task whose
 * checkpoint is at that phase. A phase that starts an external effect writes the
 * in-flight checkpoint itself (`rt.commit(tx => tx.checkpoint(...))`) and then
 * performs the effect, so the in-flight phase's handler only ever runs after a
 * crash: it is the recovery path by construction.
 */
export type PhaseHandler<I, C extends Checkpoint, P extends C["phase"], R, F, H extends object> = (
	task: Task<I, CheckpointAt<C, P>> & { checkpoint: CheckpointAt<C, P> },
	rt: Runtime<H>,
	ctx: Context,
) => Promise<Step<C, R, F>>;

/** Per-kind configuration: defaults, split by document. Keys across all kinds must be disjoint. */
export interface KindConfig<RC extends object = object, SC extends object = object> {
	readonly rewindable?: RC;
	readonly sticky?: SC;
}

/**
 * A task kind. `initial` runs when there is no checkpoint; `phases` is exhaustive
 * over `C["phase"]`, so a checkpoint nobody handles is a compile error.
 * `H` is the hook interface the kind calls; `Cfg` the config it declares.
 */
/** Phantom carrier so `TaskOf<K>`, `HooksOf<K>`, `ConfigOf<K>` can read a kind's types back out. Never set at runtime. */
export interface KindTypes<I, C extends Checkpoint, R, F, A, H extends object, Cfg extends KindConfig> {
	input: I;
	checkpoint: C;
	result: R;
	failure: F;
	aborted: A;
	hooks: H;
	config: Cfg;
}

export interface Kind<I = unknown, C extends Checkpoint = Checkpoint, R = unknown, F = unknown, A = unknown, H extends object = object, Cfg extends KindConfig = KindConfig> {
	readonly types?: KindTypes<I, C, R, F, A, H, Cfg>;
	readonly name: string;
	readonly core?: boolean;
	/** A turn kind makes the conversation busy for admission. */
	readonly turn?: boolean;
	readonly config?: Cfg;
	initial(task: Task<I, never> & { checkpoint?: undefined }, rt: Runtime<H>, ctx: Context): Promise<Step<C, R, F>>;
	readonly phases: { readonly [P in C["phase"]]: PhaseHandler<I, C, P, R, F, H> };
	abort(task: Task<I, C>, rt: Runtime<H>, ctx: Context): Promise<AbortClosure<A>>;
}

/** Author an ordinary (non-core) kind. Same shape; the return keeps the literal types for refs, hooks and config. */
export function defineTask<I, C extends Checkpoint, R, F, A, H extends object = object, Cfg extends KindConfig = KindConfig>(
	definition: Omit<Kind<I, C, R, F, A, H, Cfg>, "core">,
): Kind<I, C, R, F, A, H, Cfg> {
	return Object.freeze({ ...definition, core: false });
}

/**
 * The erased kind the kernel stores. Handler parameters are `never` so every
 * concrete `Kind<…>` is assignable (function parameters are contravariant);
 * the kernel calls handlers with the real task and runtime.
 */
export interface AnyKind {
	readonly types?: unknown;
	readonly name: string;
	readonly core?: boolean;
	readonly turn?: boolean;
	readonly config?: KindConfig;
	initial(task: never, rt: never, ctx: Context): Promise<Step<Checkpoint, unknown, unknown>>;
	readonly phases: { readonly [phase: string]: (task: never, rt: never, ctx: Context) => Promise<Step<Checkpoint, unknown, unknown>> };
	abort(task: never, rt: never, ctx: Context): Promise<AbortClosure<unknown>>;
}

/** What task-creating APIs return: the id plus the kind, so later calls need nothing else. Not durable: store `.id`. */
export interface TaskRef<K extends AnyKind = AnyKind> {
	readonly id: Id;
	readonly kind: K;
}
export interface EntryRef<E extends Entry = Entry> {
	readonly id: Id;
	readonly kind: EntryKind<E>;
}

type TypesOf<K> = K extends { types?: infer T } ? NonNullable<T> : never;
/** A task record typed by its kind: `TaskOf<typeof job>` has a typed input, checkpoint and outcome. */
export type TaskOf<K> = TypesOf<K> extends KindTypes<infer I, infer C, infer R, infer F, infer A, object, KindConfig> ? Omit<Task<I, C>, "outcome"> & { readonly outcome?: Outcome<R, F, A> } : never;
export type InputOf<K> = TypesOf<K> extends KindTypes<infer I, Checkpoint, unknown, unknown, unknown, object, KindConfig> ? I : never;
export type HooksOf<K> = TypesOf<K> extends KindTypes<unknown, Checkpoint, unknown, unknown, unknown, infer H, KindConfig> ? H : never;
export type ConfigOf<K> = TypesOf<K> extends KindTypes<unknown, Checkpoint, unknown, unknown, unknown, object, infer Cfg> ? Cfg : never;

// ---------------------------------------------------------------------------
// Tx: the one transaction surface. Capability is checked at runtime against
// `invoker`; a disallowed call throws Forbidden.
// ---------------------------------------------------------------------------

export type Invoker =
	| { readonly type: "host" }
	| { readonly type: "task"; readonly id: Id; readonly conversationId: Id; readonly core: boolean; readonly mode: "run" | "abort" };

export interface ContextView {
	readonly head: Entry | undefined;
	readonly entries: Entry[]; // selected, ascending
	readonly messages: RequestMessage[]; // edits applied, results reordered, gaps synthesised
}

export interface Tx {
	readonly invoker: Invoker;

	// reads
	conversation(id: Id): Promise<Conversation | undefined>;
	entry(id: Id): Promise<Entry | undefined>;
	entry<E extends Entry>(kind: EntryKind<E>, id: Id): Promise<E | undefined>;
	entries(ids: Id[]): Promise<Map<Id, Entry>>;
	newestEntry(conversationId: Id, opts?: { kind?: string; withHead?: boolean }): Promise<Entry | undefined>;
	newestEntry<E extends Entry>(conversationId: Id, kind: EntryKind<E>): Promise<E | undefined>;
	scanEntries(scan: EntryScan): Promise<Entry[]>;
	context(conversationId: Id, at?: Id): Promise<ContextView>;
	task(id: Id): Promise<Task | undefined>;
	tasks(scan: TaskScan): Promise<Task[]>;
	input(id: Id): Promise<Input | undefined>;

	// documents: tracked proxies, valid inside this transaction only
	rewindable(conversationId: Id): RewindableState;
	sticky(conversationId: Id): StickyState;
	session(): SessionState;
	/** A non-turn task's slot: `sticky.tasks[id]`, created on demand, retired on terminal. */
	slot<T extends object>(task: { id: Id; conversationId: Id }): T;
	/** A tool task's slot: `sticky.turn.tools[index]`. Lives with the turn. */
	toolSlot(task: { conversationId: Id; input: { index: number } }): ToolSlot;
	/** Plain copies (the proxies above cannot be cloned or escape the transaction). */
	snapshot(ref: { doc: "rewindable"; conversationId: Id }): RewindableState;
	snapshot(ref: { doc: "sticky"; conversationId: Id }): StickyState;
	snapshot(ref: { doc: "session" }): SessionState;

	// writes
	appendEntry(conversationId: Id, entry: NewEntry): Id; // core task only
	appendEntry<E extends Entry>(conversationId: Id, kind: EntryKind<E>, entry: EntryInput<E>): EntryRef<E>;
	write(conversationId: Id, entry: NewEntry): Promise<Id>; // anyone; queued when busy. Returns the input id.
	write<E extends Entry>(conversationId: Id, kind: EntryKind<E>, entry: EntryInput<E>): Promise<Id>;
	createTask(spec: TaskSpec): Id;
	createTask<K extends AnyKind>(kind: K, input: InputOf<K>, opts?: { conversationId?: Id; background?: true; after?: Id[] }): TaskRef<K>;
	checkpoint<C extends Checkpoint>(value: C): void; // own task only
	createConversation(spec: ConversationSpec): Id;
	markTask(id: Id): Promise<"marked" | "terminal">;

	// admission and boundaries (core task or host)
	send(conversationId: Id, input: SendInput): Promise<Id>; // returns input id
	setInput(id: Id, patch: Partial<Omit<Input, "id" | "conversationId">>): Promise<void>;
	resolveInputs(ids: Id[], resolution: Pick<Input, "status" | "answer" | "reason" | "detail">): Promise<void>;
	/** Place queued items per mode. Returns placed steer/followUp input ids and whether a self-head ended the old group. */
	boundary(conversationId: Id, at: "postTools" | "final"): Promise<{ triggers: Id[]; terminated: boolean }>;
	busy(conversationId: Id): Promise<boolean>;
}

export interface TaskSpec {
	kind: string;
	conversationId?: Id; // defaults to the invoker's
	input: unknown;
	after?: Id[];
	background?: true;
}
export interface ConversationSpec {
	parent?: { conversationId: Id; at: Id | "start" };
	rewindable?: Partial<RewindableState>;
	sticky?: Partial<StickyState>;
	sections?: import("./system.ts").SectionSeed[];
}
export interface SendInput {
	content: UserInput;
	requestId?: string;
	whenBusy?: "followUp" | "steer" | "reject";
}

// ---------------------------------------------------------------------------
// Runtime: the one runtime surface a kind method receives.
// ---------------------------------------------------------------------------

export interface Models {
	resolve(ref: ModelRef): Model<Api> | undefined;
	stream(model: Model<Api>, request: { messages: RequestMessage[]; thinkingLevel: ThinkingLevel }, ctx: Context): AsyncIterable<AssistantMessageEvent>;
	fetchDeferred(model: Model<Api>, handle: DeferredHandle, ctx: Context): Promise<AssistantMessage | { deferred: DeferredHandle }>;
	cancelDeferred(model: Model<Api>, handle: DeferredHandle, ctx: Context): Promise<void>;
}

export interface ToolDeclaration<P extends TSchema = TSchema> {
	readonly name: string;
	readonly description: string;
	readonly parameters: P;
	readonly replay?: "safe" | "unsafe";
	readonly output?: { maxBytes?: number; maxLines?: number; retain?: "head" | "tail" };
	execute(args: unknown, api: ToolApi, ctx: Context): Promise<ToolResult>;
}
export interface ToolResult<D = unknown> {
	/** Omit when the tool streamed through `api.stream`: the bounded stream is the content. */
	content?: (TextContent | ImageContent)[];
	details?: D;
	isError?: boolean;
	diagnostics?: { severity: "info" | "warn" | "error"; message: string; code?: string }[];
	control?: ToolControl;
}
export type ToolControl = { terminate?: true; handoff?: string; addTools?: string[] };
/** What a tool receives. Narrow by design. */
export interface ToolApi {
	readonly taskId: Id;
	readonly conversationId: Id;
	/**
	 * Pipe raw output here. The kernel bounds it per the declaration's `output`,
	 * flushes it to the live slot on a throttle, and uses it as the result content
	 * unless the tool returns its own. Synchronous; never blocks the producer.
	 */
	stream(chunk: string | Uint8Array): void;
	/** Mutate the rest of the live slot (progress text, structured details, `continuedBy`). */
	progress(update: (slot: ToolSlot) => void, ctx: Context): Promise<void>;
	/**
	 * Create a conversation owned by this task. `inherit: true` forks the task's own
	 * conversation at its current tip (transcript and rewindable config); otherwise it
	 * starts empty with the given documents. Either way it is a different agent.
	 */
	conversation(spec: { inherit?: boolean; rewindable?: Partial<RewindableState>; sticky?: Partial<StickyState> }, ctx: Context): Promise<OwnedConversation>;
	/** Schedule a task. The returned ref carries the kind, so `waitForTask(ref)` is typed with nothing else passed. */
	task<K extends AnyKind>(kind: K, input: InputOf<K>, opts: { background?: true; after?: Id[] }, ctx: Context): Promise<TaskRef<K>>;
	task(spec: TaskSpec, ctx: Context): Promise<TaskRef>;
	getTask<K extends AnyKind>(ref: TaskRef<K>, ctx: Context): Promise<TaskOf<K> | undefined>;
	waitForTask<K extends AnyKind>(ref: TaskRef<K>, ctx: Context): Promise<TaskOf<K>>;
	/** Snapshot of another task's live slot (`sticky.tasks[id]`), e.g. a job's stdout so far. */
	slot<T extends object>(ref: TaskRef | Id, ctx: Context): Promise<T | undefined>;
}

/** The narrow handle a task gets to a conversation it owns. */
export interface OwnedConversation {
	readonly id: Id;
	send(input: SendInput, ctx: Context): Promise<{ id: Id; wait(ctx: Context): Promise<Input>; result(ctx: Context): Promise<Input | undefined> }>;
	abort(ctx: Context): Promise<void>;
}

export interface ProcessSpec {
	command: string;
	args: string[];
	cwd: string;
	env?: Record<string, string>;
}
export type ProcessStatus =
	| { status: "running"; stdout: string; stderr: string; droppedStdout: number; droppedStderr: number }
	| { status: "exited"; exitCode: number; stdout: string; stderr: string; droppedStdout: number; droppedStderr: number }
	| { status: "unknown" };
export interface ProcessHost {
	start(key: string, spec: ProcessSpec, ctx: Context): Promise<void>;
	status(key: string, ctx: Context): Promise<ProcessStatus>;
	kill(key: string, signal: "SIGTERM" | "SIGKILL", ctx: Context): Promise<void>;
}

export interface Runtime<H extends object = object> {
	readonly taskId: Id;
	readonly conversationId: Id;
	commit<T>(fn: (tx: Tx, current: Task) => T | Promise<T>, ctx: Context): Promise<T>;
	/** This kind's registered hook handlers, scoped to the task's conversation. */
	readonly hooks: HookRunner<H>;
	readonly models: Models;
	readonly tools: ReadonlyMap<string, ToolDeclaration>;
	readonly registries: { sections: import("./system.ts").SectionRegistry; tools: import("./system.ts").ToolRegistry };
	readonly kinds: ReadonlyMap<string, AnyKind>;
	/** Rewindable document as of an entry (fork inheritance). */
	rewindableAsOf(conversationId: Id, at: Id, ctx: Context): Promise<RewindableState | undefined>;
	/** Abort a whole conversation this task owns (used by OwnedConversation.abort). */
	abortConversation(id: Id, ctx: Context): Promise<void>;
	readonly processHost: ProcessHost | undefined;
	readonly plugins: ReadonlyMap<string, PluginHandler>;
	waitForTask(id: Id, ctx: Context): Promise<Task>;
	waitForInput(id: Id, ctx: Context): Promise<Input>;
	abortTask(id: Id, ctx: Context): Promise<"marked" | "terminal">;
	now(): number;
	sleep(untilMs: number, ctx: Context): Promise<void>;
	// off-line convenience reads (a phase with nothing to write should not open a commit)
	context(conversationId: Id, at: Id | undefined, ctx: Context): Promise<ContextView>;
	newestEntry(conversationId: Id, opts: { kind?: string; withHead?: boolean }, ctx: Context): Promise<Entry | undefined>;
	rewindable(conversationId: Id, ctx: Context): Promise<RewindableState>;
	sticky(conversationId: Id, ctx: Context): Promise<StickyState>;
}

export type PluginHandler = (input: unknown, api: ToolApi, ctx: Context) => Promise<unknown>;

/** Compile-time assertion helper. */
export type Assert<T extends true> = T;

// ---------------------------------------------------------------------------
// Hooks: declared by the kind that calls them. A kind's `H` is an object of
// optional methods; the runner supplies the applicable handlers in order
// (harness-wide first, then outermost conversation to innermost) and one
// fold helper. Error policy is the kind's: `each` skips and reports a throw;
// a kind that wants throw-to-block calls handlers itself.
// ---------------------------------------------------------------------------

export interface HookInfo {
	readonly taskId: Id;
	readonly conversationId: Id;
}
export interface HookRunner<H extends object> {
	/** Applicable handler objects for this task, in order. */
	handlers(): readonly Partial<H>[];
	/**
	 * Call `fn` on each handler; `onValue` sees non-undefined results and may
	 * return true to stop. A throwing handler is reported and skipped.
	 */
	each<V>(ctx: Context, fn: (h: Partial<H>) => V | undefined | void | Promise<V | undefined | void>, onValue?: (v: V) => boolean | void): Promise<void>;
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

export class Forbidden extends Error {
	constructor(what: string) {
		super(`Forbidden: ${what}`);
		this.name = "Forbidden";
	}
}
export class Closed extends Error {
	constructor() {
		super("Session is closed");
		this.name = "Closed";
	}
}
export class Faulted extends Error {
	constructor(cause: unknown) {
		super(`Session faulted: ${String(cause)}`);
		this.name = "Faulted";
	}
}
export class ConversationBusy extends Error {
	constructor() {
		super("Conversation is busy");
		this.name = "ConversationBusy";
	}
}
