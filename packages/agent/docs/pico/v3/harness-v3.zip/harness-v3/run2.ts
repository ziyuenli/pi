import { existsSync, mkdtempSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { BACKGROUND_CONTEXT, withCancel } from "@earendil-works/chord/context";
import { Type } from "@sinclair/typebox";
import { bashTool } from "./bash.ts";
import { fakeModels, type Script } from "./fake-models.ts";
import { type ConversationDelta, Harness, kinds as builtin } from "./harness.ts";
import { JsonlStorage } from "./jsonl.ts";
import { MemoryStorage } from "./memory.ts";
import type { Entry, ToolDeclaration } from "./types.ts";

const ctx = BACKGROUND_CONTEXT;
const log = (...a: unknown[]) => console.log(...a);
const kinds = (entries: Entry[]) => entries.map((e) => e.kind.replace("pi.", "")).join(" ");
const text = (e: Entry) => { const c = (e.model?.[0] as { content?: unknown } | undefined)?.content; return (typeof c === "string" ? c : JSON.stringify(c) ?? "").slice(0, 40); };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const model = { provider: "anthropic", modelId: "fake-1" };

// ---------------------------------------------------------------------------
// 1. bash tool, including a 1 GB cat
// ---------------------------------------------------------------------------

async function bashScenario(dir: string, retain: "head" | "tail") {
	log(`\n=== bash tool (retain=${retain}) ===`);
	const big = existsSync("/tmp/1gb.txt") ? "/tmp/1gb.txt" : join(dir, "1gb.txt");
	const script: Script = {
		respond(messages, call) {
			const last = [...messages].reverse().find((m) => m.role !== "system")!;
			if (last.role === "toolResult") return { text: "ok" };
			const user = String((last as { content?: unknown }).content);
			return { toolCalls: [{ name: "bash", arguments: { command: user } }] };
		},
	};
	const storage = await JsonlStorage.open(join(dir, "s"));
	const h = await Harness.open(storage, { models: fakeModels(script), tools: [bashTool({ maxBytes: 64 * 1024, retain })], root: { rewindable: { model, selectedTools: ["bash"] } } }, ctx);
	h.resume();
	const root = await h.root(ctx);

	const run = async (cmd: string) => {
		const deltas: ConversationDelta[] = [];
		const w = await root.watch(ctx);
		w.start((d) => deltas.push(d));
		const t0 = performance.now();
		const inp = await root.send({ content: cmd }, ctx);
		await inp.wait(ctx);
		await root.waitForIdle(ctx);
		const ms = performance.now() - t0;
		w.stop();
		const entries = await h.entries({ conversationId: 1, limit: 3 }, ctx);
		const result = entries.find((e) => e.kind === "pi.tool_result")!;
		const details = result.data as { details: { ms: number }; diagnostics?: { message: string }[] };
		const stickyDeltas = deltas.filter((d) => d.sticky);
		const stickyBytes = stickyDeltas.reduce((n, d) => n + JSON.stringify(d.sticky).length, 0);
		const largest = Math.max(0, ...stickyDeltas.map((d) => JSON.stringify(d.sticky).length));
		const opKinds = stickyDeltas.flatMap((d) => d.sticky!.map((op) => op[0])).join("");
		return { ms, details: details.details, diag: details.diagnostics?.[0]?.message, progressOps: stickyDeltas.length, stickyBytes, largest, opKinds, deltas: deltas.length };
	};

	log("echo:", JSON.stringify(await run("echo hello")));
	log("stderr+exit:", JSON.stringify(await run("echo oops >&2; exit 3")));

	if (!existsSync(big)) {
		const t = performance.now();
		await run(`yes 'the quick brown fox jumps over the lazy dog' | head -c 1073741824 > ${big}`);
		log(`generated 1GB in ${(performance.now() - t).toFixed(0)}ms, size=${statSync(big).size}`);
	}
	const raw0 = performance.now();
	await new Promise<void>((r) => import("node:child_process").then(({ execSync }) => { execSync(`cat ${big} > /dev/null`); r(); }));
	log(`raw 'cat 1gb > /dev/null' outside harness: ${(performance.now() - raw0).toFixed(0)}ms`);
	let best: Awaited<ReturnType<typeof run>> | undefined;
	for (let i = 0; i < 3; i++) { const r = await run(`cat ${big}`); if (!best || r.ms < best.ms) best = r; }
	const r = best!;
	log(`cat 1gb through harness (best of 3, warm): ${r.ms.toFixed(0)}ms total, tool ${r.details.ms}ms, ${r.diag}`);
	log(`  sticky writes during cat: ${r.progressOps} flushes, ${(r.stickyBytes / 1024).toFixed(1)}KB total, largest ${(r.largest / 1024).toFixed(1)}KB, op tags: ${r.opKinds.slice(0, 60)}`);
	if (existsSync("/tmp/200mb-random.txt")) {
		const rr = await run("cat /tmp/200mb-random.txt");
		log(`  random 200MB: tool ${rr.details.ms}ms, ${rr.progressOps} flushes, ${(rr.stickyBytes / 1024).toFixed(1)}KB sidecar traffic, largest ${(rr.largest / 1024).toFixed(1)}KB, tags: ${rr.opKinds.slice(0, 40)}`);
	}

	log("files:", storage.sizes());
	await h.close(ctx);
}

// ---------------------------------------------------------------------------
// 2. subagent tool + conversation abort reaching the child
// ---------------------------------------------------------------------------

const subagentTool: ToolDeclaration = {
	name: "subagent",
	description: "delegate",
	parameters: Type.Object({ task: Type.String() }),
	async execute(args, api, ctx) {
		const child = await api.conversation({ rewindable: { model, selectedTools: [] } }, ctx);
		const result = await (await child.send({ content: (args as { task: string }).task }, ctx)).wait(ctx);
		return { content: [{ type: "text", text: `child ${child.id}: ${result.status}` }], details: { child: child.id } };
	},
};

async function subagentScenario() {
	log("\n=== subagent + abort ===");
	let slow = false;
	const script: Script = {
		tokenDelayMs: 0,
		respond(messages) {
			const last = [...messages].reverse().find((m) => m.role !== "system")!;
			if (last.role === "toolResult") return { text: "delegated and done" };
			const user = String((last as { content?: unknown }).content);
			if (user.startsWith("delegate:")) return { toolCalls: [{ name: "subagent", arguments: { task: user.slice(9) } }] };
			if (user.startsWith("slow")) { slow = true; return { text: "word ".repeat(2000) }; }
			return { text: `child answer to ${user}` };
		},
	};
	const h = await Harness.open(new MemoryStorage(), { models: fakeModels({ ...script, tokenDelayMs: 1 }), tools: [subagentTool], root: { rewindable: { model, selectedTools: ["subagent"] } } }, ctx);
	h.resume();
	const root = await h.root(ctx);

	// Happy path: parent delegates, child answers, parent finishes.
	const in1 = await root.send({ content: "delegate:quick job" }, ctx);
	await in1.wait(ctx);
	await root.waitForIdle(ctx);
	const rootEntries = (await h.entries({ conversationId: 1, limit: 20 }, ctx)).reverse();
	const tr = rootEntries.find((e) => e.kind === "pi.tool_result")!;
	log("tool result:", JSON.stringify(tr.model?.[0]).slice(0, 200), JSON.stringify(tr.data).slice(0, 200));
	const childId = (tr.data as { details: { child: number } }).details.child;
	const childEntries = (await h.entries({ conversationId: childId, limit: 20 }, ctx)).reverse();
	log("parent:", kinds(rootEntries), "| child", childId, ":", kinds(childEntries), "->", text(childEntries[childEntries.length - 1]!));

	// Abort path: child streams slowly; abort the parent conversation; child must be aborted too.
	const in2 = await root.send({ content: "delegate:slow" }, ctx);
	await sleep(120);
	const liveBefore = await root.commit((tx) => tx.tasks({ status: ["pending", "running"] }), ctx);
	log("live before abort:", liveBefore.map((t) => `${t.kind.replace("pi.", "")}@${t.conversationId}`).join(" "));
	const child2Id = liveBefore.find((t) => t.conversationId !== 1)!.conversationId;
	const t0 = performance.now();
	await root.abort(ctx);
	const r2 = await in2.wait(ctx);
	log(`aborted in ${(performance.now() - t0).toFixed(0)}ms: input ${r2.status}/${r2.reason}; slow child ran: ${slow}`);
	const child2 = (await h.entries({ conversationId: child2Id, limit: 20 }, ctx)).reverse();
	const child2Tasks = await root.commit((tx) => tx.tasks({ conversationId: child2Id }), ctx);
	log(`child ${child2Id} transcript:`, kinds(child2), "| child tasks:", child2Tasks.map((t) => `${t.kind.replace("pi.", "")}:${t.status}:${t.outcome?.status}`).join(" "), "| parent tail:", kinds((await h.entries({ conversationId: 1, limit: 3 }, ctx)).reverse()));
	log("live after abort:", (await root.commit((tx) => tx.tasks({ status: ["pending", "running"] }), ctx)).length);
	await h.close(ctx);
}

// ---------------------------------------------------------------------------
// 3. reset / handoff: self-head staling of queued input
// ---------------------------------------------------------------------------

async function resetScenario() {
	log("\n=== reset + handoff staling ===");
	const script: Script = {
		tokenDelayMs: 2,
		respond(messages) {
			const last = [...messages].reverse().find((m) => m.role !== "system")!;
			if (last.role === "toolResult") return { text: "after tool" };
			const user = String((last as { content?: unknown }).content);
			if (user === "handoff") return { toolCalls: [{ name: "hand", arguments: {} }] };
			return { text: `answer(${user}) with some padding words here` };
		},
	};
	const hand: ToolDeclaration = { name: "hand", description: "", parameters: Type.Object({}), async execute() { return { content: [{ type: "text", text: "handing off" }], control: { handoff: "fresh start" } }; } };
	const h = await Harness.open(new MemoryStorage(), { models: fakeModels(script), tools: [hand], root: { rewindable: { model, selectedTools: ["hand"] }, sticky: { followUpMode: "one-at-a-time" } } }, ctx);
	h.resume();
	const root = await h.root(ctx);

	// Busy; queue B1, B2 (followUp), then a reset. Expect: B1, B2 stale; no generation for them.
	const a = await root.send({ content: "A" }, ctx);
	const b1 = await root.send({ content: "B1" }, ctx);
	const b2 = await root.send({ content: "B2" }, ctx);
	await root.reset(undefined, ctx);
	await a.wait(ctx);
	await root.waitForIdle(ctx);
	log("A:", (await a.result(ctx))?.status, "| B1:", (await b1.result(ctx))?.status, (await b1.result(ctx))?.reason, "| B2:", (await b2.result(ctx))?.status, (await b2.result(ctx))?.reason);
	log("transcript:", (await h.entries({ conversationId: 1, limit: 20 }, ctx)).reverse().map((e) => `${e.kind.replace("pi.", "")}${e.head ? "*" : ""}`).join(" "));
	log("context after reset:", kinds((await root.commit((tx) => tx.context(1), ctx)).entries));

	// Then: a followUp C admitted AFTER the reset should still run.
	const c = await root.send({ content: "C" }, ctx);
	await c.wait(ctx);
	log("C after reset:", (await c.result(ctx))?.status, "| context:", kinds((await root.commit((tx) => tx.context(1), ctx)).entries));

	// Handoff via tool control at a post-tools boundary with a followUp queued: followUp starts in the fresh context.
	const hd = await root.send({ content: "handoff" }, ctx);
	const d = await root.send({ content: "D" }, ctx);
	await hd.wait(ctx);
	await d.wait(ctx);
	await root.waitForIdle(ctx);
	const tail = (await h.entries({ conversationId: 1, limit: 8 }, ctx)).reverse();
	log("handoff tail:", tail.map((e) => `${e.kind.replace("pi.", "")}${e.head ? "*" : ""}`).join(" "), "| D:", (await d.result(ctx))?.status);
	log("context after handoff:", kinds((await root.commit((tx) => tx.context(1), ctx)).entries));
	await h.close(ctx);
}

// ---------------------------------------------------------------------------
// 4. fork of a fork: docAsOf through the chain
// ---------------------------------------------------------------------------

async function forkOfFork() {
	log("\n=== fork of fork ===");
	const h = await Harness.open(new MemoryStorage(), { models: fakeModels({ respond: () => ({ text: "x" }) }), root: { rewindable: { model } } }, ctx);
	h.resume();
	const root = await h.root(ctx);
	await root.commit((tx) => { tx.rewindable(1).plugins.v = 1; }, ctx);
	await root.write({ kind: "pi.notice", model: [{ role: "user", content: "n1", timestamp: 0 }] }, ctx);
	const e1 = (await h.entries({ conversationId: 1, limit: 1 }, ctx))[0]!;
	await root.commit((tx) => { tx.rewindable(1).plugins.v = 2; }, ctx);
	const f1 = await root.fork(e1.id, {}, ctx); // sees v=1
	await f1.commit((tx) => { tx.rewindable(f1.id).plugins.v = 10; }, ctx);
	await f1.write({ kind: "pi.notice", model: [{ role: "user", content: "n2", timestamp: 0 }] }, ctx);
	const e2 = (await h.entries({ conversationId: f1.id, limit: 1 }, ctx))[0]!;
	await f1.commit((tx) => { tx.rewindable(f1.id).plugins.v = 11; }, ctx);
	const f2 = await f1.fork(e2.id, {}, ctx); // sees v=10
	const f3 = await f1.fork(e1.id, {}, ctx); // fork of f1 at an entry that belongs to root: sees v=1
	log("root v:", (await root.rewindable(ctx)).plugins.v, "| f1 v:", (await f1.rewindable(ctx)).plugins.v, "| f2 (f1@n2) v:", (await f2.rewindable(ctx)).plugins.v, "| f3 (f1@n1) v:", (await f3.rewindable(ctx)).plugins.v);
	log("f2 context:", (await f2.commit((tx) => tx.context(f2.id), ctx)).entries.map(text).join(","), "| f3 context:", (await f3.commit((tx) => tx.context(f3.id), ctx)).entries.map(text).join(","));
	log((await f2.rewindable(ctx)).plugins.v === 10 && (await f3.rewindable(ctx)).plugins.v === 1 ? "FORK-OF-FORK OK" : "FORK-OF-FORK FAILED");
	await h.close(ctx);
}

const base = mkdtempSync(join(tmpdir(), "v3x-"));
try {
	await bashScenario(base, "head");
	await bashScenario(base, "tail");
	await subagentScenario();
	await resetScenario();
	await forkOfFork();
} finally {
	rmSync(base, { recursive: true, force: true });
}
