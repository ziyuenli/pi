import type { Context } from "@earendil-works/chord";
import type { Api, AssistantMessage, AssistantMessageEvent, Model, ToolCall, ToolResultMessage } from "@earendil-works/pi-ai";
import type { Models, RequestMessage } from "./types.ts";

export interface Script {
	/** Decide the response from the request. */
	respond(messages: RequestMessage[], call: number): { text?: string; toolCalls?: { name: string; arguments: unknown }[]; error?: string };
	/** ms between tokens; 0 = as fast as possible. */
	tokenDelayMs?: number;
	/** Called before each token; return true to hang forever (crash test). */
	hang?: (token: number) => boolean;
}

const usage = (input: number, output: number): AssistantMessage["usage"] => ({
	input, output, cacheRead: 0, cacheWrite: 0, totalTokens: input + output,
	cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 },
});

export function fakeModels(script: Script): Models & { calls: number } {
	const model: Model<"anthropic-messages"> = {
		id: "fake-1", name: "Fake", api: "anthropic-messages", provider: "anthropic", baseUrl: "", reasoning: false,
		input: ["text"], cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, contextWindow: 200_000, maxTokens: 8192,
	};
	const sleep = (ms: number, ctx: Context) =>
		new Promise<void>((resolve, reject) => {
			const t = setTimeout(resolve, ms);
			ctx.abortSignal?.addEventListener("abort", () => { clearTimeout(t); reject(ctx.abortSignal?.reason ?? new Error("aborted")); });
		});

	const api = {
		calls: 0,
		resolve: () => model as Model<Api>,
		async *stream(_m: Model<Api>, request: { messages: RequestMessage[] }, ctx: Context): AsyncIterable<AssistantMessageEvent> {
			const n = api.calls++;
			const r = script.respond(request.messages, n);
			const partial: AssistantMessage = {
				role: "assistant", content: [], api: model.api, provider: model.provider, model: model.id,
				usage: usage(0, 0), stopReason: "stop", timestamp: Date.now(),
			};
			yield { type: "start", partial };
			if (r.error !== undefined) {
				yield { type: "error", reason: "error", error: { ...partial, stopReason: "error", errorMessage: r.error } };
				return;
			}
			let index = 0;
			let tok = 0;
			if (r.text !== undefined) {
				partial.content.push({ type: "text", text: "" });
				yield { type: "text_start", contentIndex: index, partial };
				for (const word of r.text.split(" ")) {
					if (script.hang?.(tok++)) await new Promise(() => {}); // hang forever
					if (script.tokenDelayMs) await sleep(script.tokenDelayMs, ctx);
					ctx.abortSignal?.throwIfAborted();
					const delta = `${word} `;
					(partial.content[index] as { text: string }).text += delta;
					yield { type: "text_delta", contentIndex: index, delta, partial };
				}
				yield { type: "text_end", contentIndex: index, content: (partial.content[index] as { text: string }).text, partial };
				index++;
			}
			for (const tc of r.toolCalls ?? []) {
				const call: ToolCall = { type: "toolCall", id: `call_${n}_${index}`, name: tc.name, arguments: tc.arguments as Record<string, unknown> };
				partial.content.push(call);
				yield { type: "toolcall_start", contentIndex: index, partial };
				yield { type: "toolcall_end", contentIndex: index, toolCall: call, partial };
				index++;
			}
			const message: AssistantMessage = { ...partial, usage: usage(request.messages.length * 50, tok), stopReason: r.toolCalls?.length ? "toolUse" : "stop" };
			yield { type: "done", reason: message.stopReason as "stop" | "toolUse", message };
		},
		async fetchDeferred() { throw new Error("not deferred"); },
		async cancelDeferred() {},
	};
	return api;
}

export type { ToolResultMessage };
